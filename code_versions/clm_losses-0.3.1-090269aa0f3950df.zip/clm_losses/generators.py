"""Panel de generadores para T-gen (ENMIENDA_03; reemplaza a P3).

Para cada generador del panel: los mismos ítems del test (≤ 1 por documento, orden fijo), el mismo prompt
y el mismo muestreo. Pasos (cada uno reanudable y guardado en Drive, en data/eval/tgen/<split>/<clave>/):

    1. textos      pregunta y oro de los ítems (tokens públicos de Nemotron-DQA, decodificados con Qwen3)
    2. generar     un subproceso por generador (clm_losses.genworker): libera la GPU al terminar
    3. embeber     Qwen3-8B con el pipeline validado por G1; filtro de falsos negativos (coseno > 0.95 al oro)
    4. auditar     sondas ciegas: longitud, ciego de Gemini transferido, ciego propio (validación cruzada),
                   coseno crudo; matriz de transferencia entre ciegos
    5. panel       PANEL.json: qué generadores entran al macro de T-gen (regla fija, §3.6 de la enmienda)

Hecho que motiva los controles [VERIFIED, tarjeta de nvidia/Nemotron-CC-v2.1]: el oro (High-Quality-DQA)
lo escribió Qwen3-30B-A3B. Un generador de otra familia deja un estilo distinto del oro, que un modelo
ciego podría reconocer: por eso cada generador se audita por separado.
"""
from __future__ import annotations

import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from dataclasses import asdict, dataclass, field

import numpy as np

from .utils import (append_jsonl, atomic_np_save, load_json, makedirs, now_iso, read_jsonl, save_json)

PROMPT_VERSION = "tgen-v1"
PROMPT = (
    "You are helping build a benchmark of hard incorrect answers for question answering.\n\n"
    "Question: {question}\n"
    "Correct answer: {answer}\n\n"
    "Write {k} different answers to the question that are plausible and on-topic but factually INCORRECT.\n"
    "Rules:\n"
    "- Each answer must have about the same length as the correct answer (around {n_words} words) and the "
    "same style and format.\n"
    "- Do not copy, paraphrase, or simply negate the correct answer; each one must state something wrong.\n"
    "- Do not say that the answers are incorrect and do not add explanations.\n"
    "Return exactly {k} lines, one answer per line, with no numbering, bullets, or extra text."
)

K_KEEP = 10          # negativos por ítem en el set final (como T-gem)
K_REQUEST = 14       # se piden 4 de reserva (parseo y filtro de falsos negativos)
FN_THRESHOLD = 0.95  # mismo umbral que T-mine
BANDS = (0.15, 0.30)  # bandas de G3


@dataclass(frozen=True)
class Generator:
    key: str
    repo: str
    family: str
    role: str                 # primario | control_gemini | control_qwen | control_oro
    license: str
    gated: bool
    params_b: float
    chat_kwargs: dict = field(default_factory=dict)
    harmony: bool = False     # formato "harmony" (gpt-oss): se guarda sólo el canal final
    min_transformers: str = "4.53"
    n_items: int | None = None  # None = los N del panel; los controles pesados usan menos
    dtype: str = "bfloat16"
    note: str = ""
    model_kwargs: dict = field(default_factory=dict)
    # salida con bloque de razonamiento (p. ej. Gemma 4): se guarda sólo lo que sigue a final_marker; si aparece
    # reasoning_start sin final_marker (razonamiento sin cerrar), la salida se descarta
    final_marker: str | None = None
    reasoning_start: str | None = None
    tier: str | None = None   # "chico" (2.6–9.4B densos) | "grande" (14–34B densos) | None (MoE): análisis por tamaño


# Verificado en la API de Hugging Face el 2026-10-01 (repo, gated, licencia, arquitectura, parámetros).
_C, _G = "chico", "grande"
PANEL: list[Generator] = [
    Generator("mistral7b", "mistralai/Mistral-7B-Instruct-v0.3", "Mistral AI", "primario", "apache-2.0", False, 7.25,
              tier=_C),
    Generator("phi4mini", "microsoft/Phi-4-mini-instruct", "Microsoft (Phi)", "primario", "mit", False, 3.84, tier=_C),
    Generator("olmo2_7b", "allenai/OLMo-2-1124-7B-Instruct", "AI2 (OLMo)", "primario", "apache-2.0", False, 7.30,
              tier=_C),
    Generator("granite33_8b", "ibm-granite/granite-3.3-8b-instruct", "IBM (Granite)", "primario", "apache-2.0",
              False, 8.17, tier=_C),
    Generator("falcon3_7b", "tiiuae/Falcon3-7B-Instruct", "TII (Falcon)", "primario", "other (Falcon)", False, 7.46,
              tier=_C),
    Generator("yi15_9b", "01-ai/Yi-1.5-9B-Chat", "01.AI (Yi)", "primario", "apache-2.0", False, 8.83, tier=_C),
    Generator("glm4_9b", "zai-org/glm-4-9b-chat-hf", "Zhipu / Z.ai (GLM)", "primario", "other (glm-4)", False, 9.40,
              tier=_C),
    Generator("smollm3_3b", "HuggingFaceTB/SmolLM3-3B", "Hugging Face (SmolLM)", "primario", "apache-2.0", False,
              3.08, chat_kwargs={"enable_thinking": False}, tier=_C),
    Generator("apertus8b", "swiss-ai/Apertus-8B-Instruct-2509", "Swiss AI (Apertus)", "primario", "apache-2.0",
              False, 8.05, min_transformers="4.56", tier=_C),
    Generator("lfm2_2b6", "LiquidAI/LFM2-2.6B", "Liquid AI (LFM2)", "primario", "other (lfm1.0)", False, 2.57,
              min_transformers="4.55", tier=_C),
    Generator("gptoss20b", "openai/gpt-oss-20b", "OpenAI (gpt-oss)", "primario", "apache-2.0", False, 20.9,
              chat_kwargs={"reasoning_effort": "low"}, harmony=True, min_transformers="4.55", dtype="bfloat16",
              note="MoE con pesos MXFP4 (se des-cuantizan a bf16, ~42 GB); razonamiento bajo; sólo el canal final",
              model_kwargs={"dequantize_mxfp4": True}),
    Generator("llama31_8b", "meta-llama/Llama-3.1-8B-Instruct", "Meta (Llama)", "primario", "llama3.1", True, 8.03,
              tier=_C),
    Generator("aya8b", "CohereLabs/aya-expanse-8b", "Cohere (Aya)", "primario", "cc-by-nc-4.0", True, 8.03, tier=_C),
    Generator("gemma2_9b", "google/gemma-2-9b-it", "Google (Gemma ≈ Gemini)", "control_gemini", "gemma", True, 9.24,
              note="misma casa que Gemini: ¿el atajo de T-gem es estilo Gemini?",
              model_kwargs={"attn_implementation": "eager"}, tier=_C),   # Gemma 2: soft-capping (recomendado: eager)
    Generator("qwen25_7b", "Qwen/Qwen2.5-7B-Instruct", "Alibaba (Qwen)", "control_qwen", "apache-2.0", False, 7.62,
              note="familia del oro y del encoder", tier=_C),
    Generator("qwen3_30b", "Qwen/Qwen3-30B-A3B", "Alibaba (Qwen3)", "control_oro", "apache-2.0", False, 30.5,
              chat_kwargs={"enable_thinking": False}, n_items=1000,
              note="el mismo modelo que escribió el oro (MoE: lento en transformers)"),
    # --- Ampliación del 2026-10-01 (ENMIENDA_03 §10; decidida antes de generar nada): los modelos más fuertes de
    # cada familia que caben en la GPU (96 GB) en bf16 y cargan con transformers. Verificados en la API de HF.
    # La celda 6.1 instala transformers >= PANEL_MIN_TRANSFORMERS (Gemma 4 lo necesita; los demás, menos).
    Generator("phi4_14b", "microsoft/phi-4", "Microsoft (Phi)", "primario", "mit", False, 14.66, tier=_G),
    Generator("mistral_small24b", "mistralai/Mistral-Small-24B-Instruct-2501", "Mistral AI", "primario", "apache-2.0",
              False, 23.57, tier=_G,
              note="Mistral Small 3.2 (2506) no trae tokenizer de transformers; 2501 es sólo texto y sí lo trae"),
    Generator("olmo31_32b", "allenai/Olmo-3.1-32B-Instruct", "AI2 (OLMo)", "primario", "apache-2.0", False, 32.23,
              tier=_G),
    Generator("glm4_32b", "zai-org/GLM-4-32B-0414", "Zhipu / Z.ai (GLM)", "primario", "mit", False, 32.57, tier=_G),
    Generator("yi15_34b", "01-ai/Yi-1.5-34B-Chat", "01.AI (Yi)", "primario", "apache-2.0", False, 34.39, tier=_G),
    Generator("aya32b", "CohereLabs/aya-expanse-32b", "Cohere (Aya)", "primario", "cc-by-nc-4.0", True, 32.30,
              tier=_G),
    Generator("gemma4_31b", "google/gemma-4-31B-it", "Google (Gemma 4 ≈ Gemini)", "control_gemini", "apache-2.0",
              False, 31.27, chat_kwargs={"enable_thinking": False}, min_transformers="5.5", tier=_G,
              final_marker="<channel|>", reasoning_start="<|channel>",
              note="control de Gemini actual; sin modo de pensamiento (la plantilla deja el bloque de pensamiento vacío)"),
]
PANEL_BY_KEY = {g.key: g for g in PANEL}
PANEL_MIN_TRANSFORMERS = "5.5"
MACRO_ROLES = ("primario",)
ROLE_TXT = {"primario": "primario", "control_gemini": "control (≈ Gemini)", "control_qwen": "control (familia Qwen)",
            "control_oro": "control (modelo del oro)", "sintetico": "sintético (smoke)"}


N_ORIGINAL = 16      # los 16 de la primera versión del panel; los siguientes son la ampliación (§10)


def resolve_keys(spec: str | list | None) -> list[str]:
    """'todos' | 'originales' | 'grandes' | 'sin_gated' | 'primarios' | 'controles' | claves separadas por coma."""
    if spec is None or spec == "" or spec == "ninguno":
        return []
    if isinstance(spec, (list, tuple)):
        keys = list(spec)
    elif spec == "todos":
        keys = [g.key for g in PANEL]
    elif spec == "sin_gated":
        keys = [g.key for g in PANEL if not g.gated]
    elif spec == "primarios":
        keys = [g.key for g in PANEL if g.role == "primario"]
    elif spec == "controles":
        keys = [g.key for g in PANEL if g.role != "primario"]
    elif spec == "originales":
        keys = [g.key for g in PANEL[:N_ORIGINAL]]
    elif spec == "grandes":
        keys = [g.key for g in PANEL[N_ORIGINAL:]]
    else:
        keys = [k.strip() for k in str(spec).split(",") if k.strip()]
    bad = [k for k in keys if k not in PANEL_BY_KEY and not k.startswith("syn_")]
    if bad:
        raise KeyError(f"generadores desconocidos {bad}; opciones: {sorted(PANEL_BY_KEY)}")
    return keys


# --------------------------------------------------------------------------------------
# Rutas
def tgen_root(study, split: str = "test") -> str:
    return study.paths.d("data", "eval", "tgen", split)


def gen_dir(study, key: str, split: str = "test") -> str:
    return os.path.join(tgen_root(study, split), key)


def panel_path(study, split: str = "test") -> str:
    return os.path.join(tgen_root(study, split), "PANEL.json")


# --------------------------------------------------------------------------------------
# Prompt y parseo
def n_words(text: str) -> int:
    return max(1, len(str(text).split()))


def build_prompt(question: str, answer: str, k: int = K_REQUEST) -> str:
    return PROMPT.format(question=question.strip(), answer=answer.strip(), k=k, n_words=n_words(answer))


def max_new_tokens_for(gold_tokens: int, k: int = K_REQUEST, harmony: bool = False) -> int:
    """Presupuesto de generación: k respuestas de ~1.6× el largo del oro + holgura (cada tokenizer cuenta
    distinto). Con razonamiento (gpt-oss) se suma espacio para el canal de análisis."""
    per = int(1.6 * max(8, int(gold_tokens))) + 8
    m = int(min(3072, max(256, 64 + k * per)))
    return m + (1024 if harmony else 0)


# Numeración y viñetas sólo si van seguidas de espacio: así no se tocan respuestas como "2.5 billion",
# "12.5%", "-40 degrees" o "3:00 pm" (la revisión independiente encontró ese error en la primera versión).
_PREFIX = re.compile(r"^\s*(?:[-*•·]+\s+|\(?\d{1,2}[.)\]]\s+|(?:incorrect\s+)?answer\s*\d*\s*[:.)\-]\s*)",
                     re.IGNORECASE)
# si el oro mismo empieza con "Answer:", no se le quita ese prefijo a los negativos (sería una diferencia de estilo)
_PREFIX_NO_ANSWER = re.compile(r"^\s*(?:[-*•·]+\s+|\(?\d{1,2}[.)\]]\s+|incorrect\s+answer\s*\d*\s*[:.)\-]\s*|"
                               r"answer\s*\d+\s*[:.)\-]\s*)", re.IGNORECASE)
_PREAMBLE = re.compile(r"\b(here (are|is)|below (are|is)|the following)\b.*\b(answers?|options|responses|lines)\b",
                       re.IGNORECASE)


def _is_preamble(s: str) -> bool:
    """Encabezados como "Here are 14 incorrect answers:" (no respuestas que empiecen con "Sure" u "OK")."""
    w = len(s.split())
    if s.endswith(":") and w <= 15:
        return True
    return w <= 15 and bool(_PREAMBLE.search(s))


def harmony_final(text: str) -> str:
    """Canal final de una salida en formato harmony (gpt-oss). Vacío si la generación no llegó a él."""
    tag = "<|channel|>final<|message|>"
    j = text.rfind(tag)
    if j < 0:
        return ""
    out = text[j + len(tag):]
    for stop in ("<|return|>", "<|end|>", "<|endoftext|>", "<|start|>"):
        k = out.find(stop)
        if k >= 0:
            out = out[:k]
    return out


def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s.strip().lower()).strip(" .;:")


def parse_negatives(text: str, gold: str, k: int = K_REQUEST, harmony: bool = False) -> list[str]:
    """Una respuesta por línea: quita numeración, viñetas, comillas y preámbulos; descarta vacías,
    copias del oro y duplicados. Devuelve como máximo k, en el orden generado."""
    if harmony:
        text = harmony_final(text)
    text = re.sub(r"<think>.*?</think>", "", text, flags=re.DOTALL)
    g = _norm(gold)
    rx = _PREFIX_NO_ANSWER if re.match(r"^\s*answer\s*[:.)\-]", str(gold), re.IGNORECASE) else _PREFIX
    seen, out = set(), []
    for line in text.splitlines():
        s = line.strip()
        for _ in range(3):                     # "• Answer 4: ..." -> dos prefijos seguidos
            t = rx.sub("", s, count=1).strip()
            if t == s:
                break
            s = t
        s = re.sub(r"[\x00-\x08\x0b-\x1f\x7f�]", "", s)       # caracteres de control / bytes inválidos
        s = s.strip().strip('"“”\'`').strip()
        if not s or len(s) < 2 or len(s) > 4000:
            continue
        if _is_preamble(s):
            continue
        low = _norm(s)
        if not low or low == g or low in seen:
            continue
        seen.add(low)
        out.append(s)
        if len(out) >= k:
            break
    return out


# --------------------------------------------------------------------------------------
# 1. Ítems y textos
def panel_order(study, test, split: str = "test", seed: int = 0) -> np.ndarray:
    """Orden fijo de ítems elegibles: ≤ 1 por documento, al azar (semilla 0). Cada generador usa un prefijo."""
    p = os.path.join(tgen_root(study, split), "panel_order.npy")
    if os.path.exists(p):
        return np.load(p)
    order = np.random.default_rng(seed).permutation(test.n)
    seen, pick = set(), []
    for i in order:
        d = test.doc_ids[i]
        if d in seen:
            continue
        seen.add(d)
        pick.append(int(i))
    arr = np.asarray(pick, np.int64)
    atomic_np_save(arr, p)
    return arr


def hf_decoder(model: str = "Qwen/Qwen3-8B"):
    """Decodifica token ids de Qwen3 (los tokens públicos de Nemotron-DQA) igual que texts.decode_items."""
    from transformers import AutoTokenizer
    tok = AutoTokenizer.from_pretrained(model)
    return lambda ids: tok.decode(ids)


def prepare_texts(study, test, n_items: int, split: str = "test", decoder=None, lookup_fn=None, log=print) -> list:
    """Pregunta y oro (texto) de los primeros n_items del orden del panel. Se guarda en items_text.jsonl
    (reanudable: sólo agrega los que faltan)."""
    root = makedirs(tgen_root(study, split))
    order = panel_order(study, test, split)
    want = [int(i) for i in order[:n_items]]
    path = os.path.join(root, "items_text.jsonl")
    have = {r["i"]: r for r in read_jsonl(path)}
    todo = [i for i in want if i not in have]
    if todo:
        if lookup_fn is None:
            from .texts import lookup as lookup_fn
        decoder = decoder or hf_decoder()
        docs = {test.doc_ids[i] for i in todo}
        log(f"[tgen] textos de {len(todo)} ítems ({len(docs)} documentos)")
        qa = {(r["doc_id"], int(r["pair_idx"])): r for r in
              lookup_fn(study.paths, docs, "qa", ["doc_id", "pair_idx", "question_ids", "answer_ids"])}
        for i in todo:
            r = qa.get((test.doc_ids[i], int(test.pair_idx[i])))
            if r is None:
                rec = {"i": i, "missing": True}
            else:
                rec = {"i": i, "doc_id": test.doc_ids[i], "pair_idx": int(test.pair_idx[i]),
                       "question": decoder(r["question_ids"]), "answer": decoder(r["answer_ids"]),
                       "gold_tokens": int(len(r["answer_ids"]))}
            append_jsonl(path, rec)
            have[i] = rec
    return [have[i] for i in want if not have[i].get("missing")]


# --------------------------------------------------------------------------------------
# 2. Generación (subproceso por generador)
def check_access(repo: str, token: str | None = None) -> tuple[bool, str]:
    """¿Se puede descargar el modelo? (gated sin licencia aceptada o sin token -> False)."""
    try:
        from huggingface_hub import HfApi
        api = HfApi(token=token or os.environ.get("HF_TOKEN") or None)
        info = api.model_info(repo)
        if getattr(info, "gated", False):
            # gated: listar archivos puede funcionar sin haber aceptado la licencia; auth_check no
            try:
                if hasattr(api, "auth_check"):
                    api.auth_check(repo)
                else:
                    from huggingface_hub import hf_hub_download
                    hf_hub_download(repo, "config.json", token=api.token, local_dir=os.path.join("/tmp", "tgen_auth", repo.replace("/", "__")))
            except Exception as e:  # noqa: BLE001
                return False, f"gated sin acceso ({type(e).__name__}); acepta la licencia en HF y usa HF_TOKEN"
        return True, f"ok (sha {str(getattr(info, 'sha', ''))[:10]})"
    except Exception as e:  # noqa: BLE001
        return False, f"{type(e).__name__}: {str(e)[:200]}"


def model_revision(repo: str, token: str | None = None) -> str | None:
    try:
        from huggingface_hub import HfApi
        return HfApi(token=token or os.environ.get("HF_TOKEN") or None).model_info(repo).sha
    except Exception:  # noqa: BLE001
        return None


def write_prompts(path: str, items: list, gen: Generator, k: int = K_REQUEST) -> int:
    makedirs(os.path.dirname(path))
    tmp = path + ".tmp"
    with open(tmp, "w") as f:
        for it in items:
            f.write(json.dumps({"i": it["i"], "prompt": build_prompt(it["question"], it["answer"], k),
                                "gold": it["answer"],
                                "max_new_tokens": max_new_tokens_for(it.get("gold_tokens", 32), k, gen.harmony)}) + "\n")
    os.replace(tmp, path)
    return len(items)


def raw_status(raw_path: str, k_keep: int = K_KEEP) -> dict:
    """Por ítem: intentos hechos y la mayor cantidad de respuestas parseadas."""
    att, best = {}, {}
    for r in read_jsonl(raw_path):
        i = r["i"]
        att[i] = att.get(i, 0) + 1
        best[i] = max(best.get(i, 0), len(r.get("negatives", [])))
    return {"attempts": att, "best": best, "complete": sum(1 for v in best.values() if v >= k_keep)}


def purge_model_cache(repo: str, hf_home: str) -> float:
    """Borra los pesos descargados de un generador (cada uno ocupa 5–60 GB del disco local)."""
    d = os.path.join(hf_home, "hub", "models--" + repo.replace("/", "--"))
    if not os.path.isdir(d):
        return 0.0
    size = sum(os.path.getsize(os.path.join(r, f)) for r, _, fs in os.walk(d) for f in fs
               if os.path.isfile(os.path.join(r, f)))
    shutil.rmtree(d, ignore_errors=True)
    return size / 1e9


def _tf_version() -> str | None:
    try:
        from importlib.metadata import version as _v
        return _v("transformers")
    except Exception:  # noqa: BLE001
        return None


def installed_transformers_ok(minimum: str | None) -> str | None:
    """None si la versión instalada de transformers alcanza `minimum`; si no, el motivo (para gen_info)."""
    if not minimum:
        return None
    try:
        from importlib.metadata import version as _v
        from packaging.version import Version
        have = _v("transformers")
        if Version(have) < Version(minimum):
            return (f"transformers {have} < {minimum}, que este modelo necesita: corre la celda 6.1 completa "
                    f"(instala transformers>={PANEL_MIN_TRANSFORMERS}) o reinicia el entorno")
    except Exception:  # noqa: BLE001
        return None
    return None


def run_generator(study, test, key: str, split: str = "test", n_items: int = 2000, k: int = K_REQUEST,
                  batch: int = 64, backend: str = "hf", temperature: float = 0.8, top_p: float = 0.95,
                  max_attempts: int = 2, seed: int = 0, python: str | None = None, hf_home: str | None = None,
                  purge: bool = True, check: bool = True, decoder=None, lookup_fn=None, log=print) -> dict:
    """Genera (o reanuda) los negativos de un generador en un subproceso. Devuelve su gen_info.json."""
    gen = PANEL_BY_KEY[key]
    gd = makedirs(gen_dir(study, key, split))
    n = int(min(gen.n_items, n_items)) if gen.n_items else int(n_items)
    raw = os.path.join(gd, "raw.jsonl")
    info_p = os.path.join(gd, "gen_info.json")
    info = load_json(info_p, {}) or {}
    st = raw_status(raw)
    items = prepare_texts(study, test, n, split, decoder=decoder, lookup_fn=lookup_fn, log=log)
    pending = [it for it in items if st["best"].get(it["i"], 0) < K_KEEP and st["attempts"].get(it["i"], 0) < max_attempts]
    if not pending:
        log(f"[tgen:{key}] ya generado: {st['complete']}/{len(items)} ítems con ≥ {K_KEEP} respuestas")
        info.update(status="generado", items_requested=len(items), items_complete=st["complete"])
        save_json(info, info_p)
        return info
    if backend == "hf":
        need = installed_transformers_ok(gen.min_transformers)
        if need:
            log(f"[tgen:{key}] se omite: {need}")
            info.update(status="sin_soporte", motivo=need, checked=now_iso())
            save_json(info, info_p)
            return info
    if check and backend != "fake":
        ok, why = check_access(gen.repo)
        if not ok:
            log(f"[tgen:{key}] se omite: {why}")
            info.update(status="sin_acceso", motivo=why, checked=now_iso())
            save_json(info, info_p)
            return info
    hf_home = hf_home or os.environ.get("HF_HOME") or os.path.join(study.paths.cache_root, "hf_home")
    prompts_p = os.path.join(study.paths.cache_root, "tgen_prompts", split, f"{key}.jsonl")
    write_prompts(prompts_p, items, gen, k)
    cmd = [python or sys.executable, "-m", "clm_losses.genworker", "generate", "--model", gen.repo,
           "--prompts", prompts_p, "--out", raw, "--backend", backend, "--batch", str(batch),
           "--temperature", str(temperature), "--top-p", str(top_p), "--k", str(k), "--k-keep", str(K_KEEP),
           "--max-attempts", str(max_attempts), "--seed", str(seed), "--dtype", gen.dtype,
           "--chat-kwargs", json.dumps(gen.chat_kwargs), "--model-kwargs", json.dumps(gen.model_kwargs)] \
        + (["--harmony"] if gen.harmony else []) \
        + (["--final-marker", gen.final_marker] if gen.final_marker else []) \
        + (["--reasoning-start", gen.reasoning_start] if gen.reasoning_start else [])
    env = dict(os.environ)
    pkg_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    env["PYTHONPATH"] = pkg_root + os.pathsep + env.get("PYTHONPATH", "")
    env["HF_HOME"] = hf_home
    env.setdefault("TOKENIZERS_PARALLELISM", "false")
    log(f"[tgen:{key}] {gen.repo}: {len(pending)} ítems pendientes de {len(items)} (backend {backend}, batch {batch})")
    t0 = time.time()
    tail = []
    proc = subprocess.Popen(cmd, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, env=env, bufsize=1)
    for line in proc.stdout:
        line = line.rstrip()
        tail = (tail + [line])[-40:]
        if line.startswith("[genworker]"):
            log(line.replace("[genworker]", f"[tgen:{key}]"))
    rc = proc.wait()
    secs = time.time() - t0
    st = raw_status(raw)
    info.update(key=key, repo=gen.repo, revision=model_revision(gen.repo) if backend != "fake" else None,
                family=gen.family, role=gen.role, license=gen.license, prompt_version=PROMPT_VERSION,
                prompt=PROMPT, k_request=k, k_keep=K_KEEP, temperature=temperature, top_p=top_p,
                max_attempts=max_attempts, seed=seed, backend=backend, dtype=gen.dtype, chat_kwargs=gen.chat_kwargs,
                final_marker=gen.final_marker, tier=gen.tier, transformers=_tf_version(),
                items_requested=len(items), items_complete=st["complete"], updated=now_iso(),
                seconds_last_call=round(secs, 1), seconds_total=round(float(info.get("seconds_total", 0.0)) + secs, 1))
    if rc != 0:
        info.update(status="fallido", error_tail=tail[-15:])
        log(f"[tgen:{key}] FALLÓ (código {rc}). Últimas líneas:\n  " + "\n  ".join(tail[-15:]))
    else:
        info.update(status="generado")
        log(f"[tgen:{key}] listo en {secs / 60:.1f} min: {st['complete']}/{len(items)} ítems con ≥ {K_KEEP} respuestas")
    save_json(info, info_p)
    if purge and backend != "fake":
        gb = purge_model_cache(gen.repo, hf_home)
        if gb:
            log(f"[tgen:{key}] borrados {gb:.1f} GB de pesos del disco local")
    return info


# --------------------------------------------------------------------------------------
# 3. Embeber y filtrar
def _merge_negatives(recs: list, gold: str) -> list[str]:
    g = _norm(gold)
    seen, out = set(), []
    for r in sorted(recs, key=lambda r: r.get("attempt", 0)):
        for s in r.get("negatives", []):
            low = _norm(s)
            if low and low != g and low not in seen:
                seen.add(low)
                out.append(s)
    return out


def _raw_sig(gd: str) -> dict:
    p = os.path.join(gd, "raw.jsonl")
    st = os.stat(p)
    return {"raw_size": int(st.st_size), "raw_mtime": float(st.st_mtime)}


def needs_embedding(study, key: str, split: str = "test") -> bool:
    """True si la generación terminó (status "generado") y no hay embebido o es anterior al raw.jsonl actual."""
    gd = gen_dir(study, key, split)
    info = load_json(os.path.join(gd, "gen_info.json")) or {}
    if info.get("status") != "generado" or not os.path.exists(os.path.join(gd, "raw.jsonl")):
        return False
    emb = load_json(os.path.join(gd, "embed_info.json"))
    if emb is None or not os.path.exists(os.path.join(gd, "negs.npy")):
        return True
    sig = _raw_sig(gd)
    return emb.get("raw_size") != sig["raw_size"] or abs(float(emb.get("raw_mtime", 0)) - sig["raw_mtime"]) > 1e-3


def embed_generator(study, test, key: str, encoder, split: str = "test", k: int = K_KEEP,
                    fn_threshold: float = FN_THRESHOLD, force: bool = False, log=print) -> dict:
    """Embebe los negativos generados (pipeline de G1), descarta los que tienen coseno crudo al oro >
    fn_threshold y guarda los primeros k válidos por ítem (items.npy, negs.npy, neg_tokens.npy).
    Sólo con la generación terminada (status "generado"); se rehace si raw.jsonl cambió."""
    gd = gen_dir(study, key, split)
    out_info = os.path.join(gd, "embed_info.json")
    info_gen = load_json(os.path.join(gd, "gen_info.json")) or {}
    if info_gen.get("status") != "generado":
        raise RuntimeError(f"{key}: la generación no terminó (estado {info_gen.get('status')!r}); vuelve a correr 6.1")
    if not force and not needs_embedding(study, key, split):
        return load_json(out_info)
    raw = read_jsonl(os.path.join(gd, "raw.jsonl"))
    if not raw:
        raise FileNotFoundError(f"{gd}: no hay negativos generados (raw.jsonl)")
    sig = _raw_sig(gd)
    for fn in ("embed_info.json", "audit.json"):          # un corte a mitad no deja un embebido o auditoría viejos
        if os.path.exists(os.path.join(gd, fn)):
            os.remove(os.path.join(gd, fn))
    texts = {r["i"]: r for r in read_jsonl(os.path.join(tgen_root(study, split), "items_text.jsonl"))
             if not r.get("missing")}
    by_item: dict = {}
    for r in raw:
        by_item.setdefault(r["i"], []).append(r)
    items = sorted(i for i in by_item if i in texts)
    cand = {i: _merge_negatives(by_item[i], texts[i]["answer"]) for i in items}
    flat = [(i, j, s) for i in items for j, s in enumerate(cand[i])]
    log(f"[tgen:{key}] embebiendo {len(flat)} respuestas de {len(items)} ítems")
    ids = encoder.tokenize([s for _, _, s in flat], keep="head")
    E = np.asarray(encoder.embed_ids(ids), np.float32)
    E /= np.linalg.norm(E, axis=1, keepdims=True) + 1e-12
    A = np.asarray(test.a_all(), np.float32)
    A /= np.linalg.norm(A, axis=1, keepdims=True) + 1e-12
    pos = 0
    keep_items, negs, toks, coss, kept_txt = [], [], [], [], []
    n_fn = n_short = 0
    for i in items:
        m = len(cand[i])
        e, L = E[pos:pos + m], [len(x) for x in ids[pos:pos + m]]
        pos += m
        c = e @ A[i]
        ok = np.nonzero(c <= fn_threshold)[0]
        n_fn += int((c > fn_threshold).sum())
        if len(ok) < k:
            n_short += 1
            continue
        sel = ok[:k]
        keep_items.append(i)
        negs.append(e[sel].astype(np.float16))
        toks.append(np.asarray(L, np.int32)[sel])
        coss.append(c[sel].astype(np.float32))
        kept_txt.append({"i": int(i), "negatives": [cand[i][j] for j in sel], "cos_to_gold": [float(x) for x in c[sel]]})
    if not keep_items:
        raise RuntimeError(f"{key}: ningún ítem quedó con {k} negativos válidos")
    NEG = np.stack(negs)
    atomic_np_save(np.asarray(keep_items, np.int64), os.path.join(gd, "items.npy"))
    atomic_np_save(NEG, os.path.join(gd, "negs.npy"))
    atomic_np_save(np.stack(toks), os.path.join(gd, "neg_tokens.npy"))
    atomic_np_save(np.stack(coss), os.path.join(gd, "neg_cos.npy"))
    tmp = os.path.join(gd, "kept.jsonl.tmp")
    with open(tmp, "w") as f:
        for r in kept_txt:
            f.write(json.dumps(r, ensure_ascii=False) + "\n")
    os.replace(tmp, os.path.join(gd, "kept.jsonl"))
    parsed = [len(cand[i]) for i in items]
    info = {"key": key, "items_generated": len(items), "items_kept": len(keep_items),
            "items_requested": info_gen.get("items_requested"), "items_short": n_short,
            "negatives_parsed_mean": float(np.mean(parsed)), "negatives_removed_fn": n_fn,
            "fn_threshold": fn_threshold, "k": k, "negs_sha": content_sha(NEG, keep_items), "created": now_iso(), **sig}
    save_json(info, out_info)                              # al final: sin él, el embebido no cuenta como hecho
    log(f"[tgen:{key}] {len(keep_items)}/{len(items)} ítems con {k} negativos válidos; "
        f"{n_fn} respuestas descartadas por parecerse al oro (coseno > {fn_threshold})")
    return info


def content_sha(negs, items) -> str:
    """Huella del contenido de un set (ítems + negativos): invalida auditorías y evaluaciones viejas."""
    h = hashlib.sha1(np.asarray(items, np.int64).tobytes())
    a = np.asarray(negs)
    h.update(str(a.shape).encode())
    h.update(np.ascontiguousarray(a).tobytes())
    return h.hexdigest()[:16]


# --------------------------------------------------------------------------------------
# 4. Auditoría (no usa ningún modelo entrenado)
def load_gen(study, key: str, split: str = "test"):
    """(items, negs) de un generador con embebido completo y consistente; None si no lo hay."""
    gd = gen_dir(study, key, split)
    p_i, p_n = os.path.join(gd, "items.npy"), os.path.join(gd, "negs.npy")
    if not (os.path.exists(p_i) and os.path.exists(p_n) and os.path.exists(os.path.join(gd, "embed_info.json"))):
        return None
    items, negs = np.load(p_i), np.load(p_n, mmap_mode="r")
    if len(items) != negs.shape[0]:
        return None                                        # escritura interrumpida: se trata como no embebido
    return items, negs


def gen_sig(study, key: str, split: str = "test") -> str | None:
    return (load_json(os.path.join(gen_dir(study, key, split), "embed_info.json")) or {}).get("negs_sha")


def _cands(A, items, negs) -> np.ndarray:
    return np.concatenate([np.asarray(A[items], np.float32)[:, None, :], np.asarray(negs, np.float32)], 1)


def train_blind_on(C: np.ndarray, hidden: int, steps: int = 300, batch: int = 128, lr: float = 1e-3,
                   seed: int = 0, device=None):
    """Modelo ciego (sólo ve los candidatos; el oro va en la columna 0) entrenado con C (n x (1+K) x H)."""
    import torch
    from .losses import BlindScorer
    dev = torch.device(device or ("cuda" if torch.cuda.is_available() else "cpu"))
    torch.manual_seed(seed)
    model = BlindScorer(hidden).to(dev)
    opt = torch.optim.AdamW(model.parameters(), lr=lr, weight_decay=1e-4)
    rs = np.random.default_rng(seed)
    X = torch.from_numpy(np.asarray(C, np.float32))
    tgt = torch.zeros(min(batch, len(C)), dtype=torch.long, device=dev)
    for _ in range(steps):
        b = rs.choice(len(C), size=min(batch, len(C)), replace=False)
        s = model(X[b].to(dev))
        loss = torch.nn.functional.cross_entropy(s, tgt[:len(b)])
        opt.zero_grad()
        loss.backward()
        opt.step()
    return model.eval()


def blind_correct(model, C: np.ndarray, bs: int = 1024) -> np.ndarray:
    import torch
    from .evaluate import rank_metrics
    dev = next(model.parameters()).device
    with torch.no_grad():
        S = np.concatenate([model(torch.from_numpy(np.asarray(C[s:s + bs], np.float32)).to(dev)).cpu().numpy()
                            for s in range(0, len(C), bs)])
    return rank_metrics(S)[1]


def band_of(x: float | None) -> str | None:
    if x is None or not np.isfinite(x):
        return None
    lo, hi = BANDS
    return "despreciable" if x < lo else ("moderado" if x < hi else "alto")


def audit_generator(study, bundle, key: str, split: str = "test", blind=None, folds: int = 5, steps: int = 300,
                    seed: int = 0, force: bool = False, log=print) -> dict | None:
    """Sondas ciegas sobre los negativos de un generador. "Atajo ciego" = el máximo de las sondas."""
    from .evaluate import rank_metrics, raw_cosine_scores
    from .texts import length_heuristic
    gd = gen_dir(study, key, split)
    p = os.path.join(gd, "audit.json")
    g = load_gen(study, key, split)
    if g is None:
        return None
    items, negs = g
    sha = gen_sig(study, key, split) or hashlib.sha1(np.asarray(items, np.int64).tobytes()).hexdigest()[:12]
    old = load_json(p)
    if old is not None and not force and old.get("items_sha") == sha and ("blind_gemini" in old or blind is None):
        return old
    test = bundle.test
    A = test.a_all()
    C = _cands(A, items, negs)
    chance = 1.0 / C.shape[1]
    res = {"key": key, "n_items": int(len(items)), "items_sha": sha, "chance": chance}
    lp = os.path.join(study.paths.d("data", "eval", split), "lengths.npz")
    pt = os.path.join(gd, "neg_tokens.npy")
    if os.path.exists(lp) and os.path.exists(pt):
        gold = np.load(lp)["gold"][items]
        nt = np.load(pt)
        res["len_gold_mean"] = float(np.mean(gold[gold >= 0])) if (gold >= 0).any() else None
        res["len_neg_mean"] = float(nt.mean())
        res["longest"] = float(np.nanmean(length_heuristic(gold, nt, "longest")))
        res["shortest"] = float(np.nanmean(length_heuristic(gold, nt, "shortest")))
    if blind is not None:
        res["blind_gemini"] = float(blind_correct(blind, C).mean())
    # ciego propio con validación cruzada (pliegues por ítem; ≤ 1 ítem por documento)
    order = np.random.default_rng(seed).permutation(len(items))
    correct = np.zeros(len(items), np.float32)
    for f in range(folds):
        te = order[f::folds]
        tr = np.setdiff1d(order, te)
        m = train_blind_on(C[tr], C.shape[2], steps=steps, seed=seed + f)
        correct[te] = blind_correct(m, C[te])
    res["blind_own_cv"] = float(correct.mean())
    atomic_np_save(correct, os.path.join(gd, "blind_own_cv_correct.npy"))
    res["raw_cosine"] = float(rank_metrics(raw_cosine_scores(test, "external", items=items, negs=np.asarray(negs)))[0]["top1"])
    probes = [res.get(x) for x in ("longest", "shortest", "blind_gemini", "blind_own_cv")]
    probes = [x for x in probes if x is not None and np.isfinite(x)]
    res["atajo_ciego"] = float(max(probes)) if probes else None
    res["banda"] = band_of(res["atajo_ciego"])
    res["created"] = now_iso()
    save_json(res, p)
    log(f"[tgen:{key}] auditoría: ciego propio {res['blind_own_cv']:.3f}"
        + (f", ciego de Gemini {res['blind_gemini']:.3f}" if "blind_gemini" in res else "")
        + (f", más larga {res['longest']:.3f}, más corta {res['shortest']:.3f}" if "longest" in res else "")
        + f", coseno crudo {res['raw_cosine']:.3f} -> atajo {res['atajo_ciego']:.3f} ({res['banda']})")
    return res


def blind_transfer_matrix(study, bundle, keys: list, split: str = "test", blind=None, steps: int = 300,
                          seed: int = 0, log=print):
    """Fila = con qué negativos se entrenó el ciego; columna = en qué negativos se evalúa. Diagonal = ciego
    propio con validación cruzada (audit.json). Fila 'gemini' = ciego de F0.6."""
    import pandas as pd
    A = bundle.test.a_all()
    data = {}
    for k in keys:
        g = load_gen(study, k, split)
        if g is not None:
            data[k] = _cands(A, g[0], g[1])
    rows = {}
    if blind is not None:
        rows["gemini (F0.6)"] = {k: float(blind_correct(blind, C).mean()) for k, C in data.items()}
    for ka, Ca in data.items():
        m = train_blind_on(Ca, Ca.shape[2], steps=steps, seed=seed)
        row = {}
        for kb, Cb in data.items():
            if ka == kb:
                row[kb] = (load_json(os.path.join(gen_dir(study, ka, split), "audit.json")) or {}).get("blind_own_cv")
            else:
                row[kb] = float(blind_correct(m, Cb).mean())
        rows[ka] = row
    df = pd.DataFrame(rows).T[list(data)] if data else pd.DataFrame()
    if len(df):
        df.to_csv(os.path.join(tgen_root(study, split), "blind_transfer.csv"))
    return df


# --------------------------------------------------------------------------------------
# 5. Panel y macro (regla fija)
def gen_status(study, key: str, split: str = "test") -> str:
    gd = gen_dir(study, key, split)
    if load_gen(study, key, split) is not None:
        return "ok" if os.path.exists(os.path.join(gd, "audit.json")) else "sin_auditar"
    info = load_json(os.path.join(gd, "gen_info.json")) or {}
    return info.get("status", "no_generado")


MIN_COVERAGE = 0.8   # fracción mínima de los ítems pedidos con 10 negativos válidos para entrar al macro
TIERS = ("grande", "chico")
TIER_METRIC = {"grande": "tgenbig", "chico": "tgensmall"}   # macro por tamaño (secundario, ENMIENDA_03 §10)


def _intersect(study, keys, split):
    items = None
    for k in keys:
        it = load_gen(study, k, split)[0]
        items = it if items is None else np.intersect1d(items, it)
    return np.asarray(items if items is not None else [], np.int64)


def freeze_panel(study, split: str = "test", keys: list | None = None, min_macro: int = 5,
                 force_macro: list | None = None, exclude_qc: dict | None = None, log=print) -> dict:
    """PANEL.json: generadores, auditoría y macro de T-gen. Regla (ENMIENDA_03 §3.6): entran al macro los de
    rol primario cuya generación TERMINÓ, con embebido y auditoría, cobertura ≥ 80 % de los ítems pedidos,
    atajo ciego NO alto y sin exclusión por el QC manual (> 5 % de falsos negativos); ítems = intersección.
    No mira ningún resultado de modelos. "todos" = lo mismo sin el criterio de atajo (el reporte de respaldo
    si quedan menos de min_macro). Si el contenido cambia, la versión anterior queda en history/.
    force_macro (test confirmatorio): el macro son exactamente los generadores congelados en el freeze."""
    root = makedirs(tgen_root(study, split))
    keys = keys or sorted({d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d)) and d != "history"})
    exclude_qc = dict(exclude_qc or {})
    gens, macro, todos, faltan = {}, [], [], []
    for k in keys:
        gen = PANEL_BY_KEY.get(k)
        aud = load_json(os.path.join(gen_dir(study, k, split), "audit.json")) or {}
        info = load_json(os.path.join(gen_dir(study, k, split), "gen_info.json")) or {}
        emb = load_json(os.path.join(gen_dir(study, k, split), "embed_info.json")) or {}
        role = gen.role if gen else info.get("role", "sintetico")
        st = gen_status(study, k, split)
        req = emb.get("items_requested") or info.get("items_requested")
        cov = (float(emb.get("items_kept", 0)) / float(req)) if req else None
        done = info.get("status") == "generado" and st == "ok"
        base_ok = bool(role in MACRO_ROLES and done and (cov is None or cov >= MIN_COVERAGE) and k not in exclude_qc)
        if force_macro is not None:
            inm = bool(k in force_macro and done)
            if k in force_macro and not done:
                faltan.append(k)
        else:
            inm = bool(base_ok and aud.get("banda") in ("despreciable", "moderado"))
        gens[k] = {"repo": gen.repo if gen else info.get("repo"), "family": gen.family if gen else info.get("family"),
                   "role": role, "tier": gen.tier if gen else info.get("tier"),
                   "status": st, "generation": info.get("status"), "items": aud.get("n_items") or emb.get("items_kept"),
                   "coverage": None if cov is None else round(cov, 4), "atajo_ciego": aud.get("atajo_ciego"),
                   "banda": aud.get("banda"), "excluido_qc": exclude_qc.get(k), "negs_sha": emb.get("negs_sha"),
                   "in_macro": inm, "revision": info.get("revision")}
        if inm:
            macro.append(k)
        if base_ok:
            todos.append(k)
    if force_macro is not None:
        faltan += [k for k in force_macro if k not in keys]
        if faltan:
            log(f"[tgen] ATENCIÓN: generadores congelados sin negativos completos en {split}: {faltan}. El macro del "
                "confirmatorio NO es el congelado hasta completarlos (8.2b).")
    items = _intersect(study, macro, split)
    items_todos = _intersect(study, todos, split)
    # análisis secundario (ENMIENDA_03 §10): el macro separado por tamaño del generador, cada uno en la
    # intersección de sus propios ítems. No cambia el macro ni ninguna regla.
    por_tamano = {}
    for t in TIERS:
        ks = [k for k in macro if gens[k]["tier"] == t]
        if ks:
            por_tamano[t] = {"keys": ks, "items": _intersect(study, ks, split).tolist()}
    sig = hashlib.sha256(json.dumps({"macro": macro, "items": items.tolist(),
                                     "sha": [gens[k]["negs_sha"] for k in macro],
                                     "tiers": {k: gens[k]["tier"] for k in macro}}).encode()).hexdigest()[:12]
    rule = ("macro = generadores de rol primario con generación terminada, embebido y auditoría, cobertura ≥ 80 %, "
            "atajo ciego (máximo de longitud, ciego de Gemini y ciego propio) < 30 % y sin exclusión por QC; "
            "ítems = intersección. No depende de resultados de modelos.")
    if force_macro is not None:
        rule = f"macro fijado por el PROTOCOL FREEZE: {list(force_macro)}; ítems = intersección."
    panel = {"split": split, "version": sig, "created": now_iso(), "rule": rule,
             "generators": gens, "macro": macro, "macro_items": items.tolist(), "n_macro_items": int(len(items)),
             "todos": todos, "todos_items": items_todos.tolist(), "macro_por_tamano": por_tamano,
             "robusto": len(macro) >= min_macro,
             "min_macro": min_macro, "faltan_del_freeze": faltan if force_macro is not None else None,
             "exclusiones_qc": exclude_qc}
    p = panel_path(study, split)
    old = load_json(p)
    if old is not None and old.get("version") != sig:
        save_json(old, os.path.join(root, "history", f"PANEL_{old.get('version')}.json"))
    if old is None or old.get("version") != sig or old.get("generators") != gens or old.get("todos") != todos:
        save_json(panel, p)
    else:
        panel = old
    if not panel["robusto"]:
        log(f"[tgen] ATENCIÓN: sólo {len(macro)} generadores en el macro (mínimo {min_macro}). Ver ENMIENDA_03 §3.6: "
            "se reporta además el macro de todos los primarios ('tgenall', con atajo) y los controles.")
    return panel


def load_panel(study, split: str = "test") -> dict | None:
    return load_json(panel_path(study, split))


def _local_copy(src: str, dst: str) -> str:
    """Copia a disco local (lecturas rápidas; Drive es lento para leer lo mismo en cada evaluación)."""
    try:
        if os.path.exists(dst) and os.path.getsize(dst) == os.path.getsize(src) \
                and os.path.getmtime(dst) >= os.path.getmtime(src):
            return dst
        makedirs(os.path.dirname(dst))
        tmp = dst + ".tmp"
        shutil.copyfile(src, tmp)
        os.replace(tmp, dst)
        return dst
    except OSError:
        return src


def load_panel_sets(study, split: str = "test", localize: bool = True) -> dict:
    """{"tgen_<clave>": (items, negs, huella)} de todos los generadores con embebido completo (macro o no).
    La huella (contenido de ítems + negativos) invalida evaluaciones viejas si los negativos cambian. Los
    negativos se leen de una copia en el disco local (se rehace sola si cambian en Drive)."""
    root = tgen_root(study, split)
    out = {}
    if not os.path.isdir(root):
        return out
    for k in sorted(os.listdir(root)):
        if k == "history" or not os.path.isdir(os.path.join(root, k)):
            continue
        g = load_gen(study, k, split)
        if g is None:
            continue
        p_n = os.path.join(root, k, "negs.npy")
        if localize and not study.data.synthetic:
            p_n = _local_copy(p_n, study.paths.c("tgen_local", split, k, "negs.npy"))
        out[f"tgen_{k}"] = (g[0], np.load(p_n, mmap_mode="r"), gen_sig(study, k, split))
    return out


MACRO_FILES = ("correct_{n}.npy", "correct_{n}_shuf.npy", "items_{n}.npy", "{n}.json")


def _clear_macro(ev: str, name: str) -> None:
    for f in MACRO_FILES:
        p = os.path.join(ev, f.format(n=name))
        if os.path.exists(p):
            os.remove(p)


def _macro(ev: str, keys: list, items: np.ndarray, version: str, name: str, extra_sigs: dict) -> dict | None:
    """Promedio por ítem del acierto sobre `keys`, alineado en `items`. Si falta algo, borra el macro viejo."""
    sig_p = os.path.join(ev, f"{name}.json")
    old = load_json(sig_p)
    if old and old.get("version") == version and os.path.exists(os.path.join(ev, f"correct_{name}.npy")):
        return old
    cols, cols_s = [], []
    for k in keys:
        tn = f"tgen_{k}"
        pc, pi = os.path.join(ev, f"correct_{tn}.npy"), os.path.join(ev, f"items_{tn}.npy")
        if not (os.path.exists(pc) and os.path.exists(pi)) or (extra_sigs.get(k) and
                                                               (load_json(os.path.join(ev, "extra_sigs.json")) or {}).get(tn) != extra_sigs[k]):
            _clear_macro(ev, name)
            return None
        it = np.load(pi)
        if not np.isin(items, it).all():
            _clear_macro(ev, name)
            return None
        o = np.argsort(it)
        pos = o[np.searchsorted(it[o], items)]
        cols.append(np.load(pc)[pos])
        ps = os.path.join(ev, f"correct_{tn}_shuf.npy")
        cols_s.append(np.load(ps)[pos] if os.path.exists(ps) else None)
    M = np.mean(cols, 0).astype(np.float32)
    atomic_np_save(M, os.path.join(ev, f"correct_{name}.npy"))
    atomic_np_save(items, os.path.join(ev, f"items_{name}.npy"))
    out = {"version": version, "keys": list(keys), "n": int(len(items)), "top1": float(M.mean())}
    if all(c is not None for c in cols_s):
        Ms = np.mean(cols_s, 0).astype(np.float32)
        atomic_np_save(Ms, os.path.join(ev, f"correct_{name}_shuf.npy"))
        out["shuf_top1"] = float(Ms.mean())
    save_json(out, sig_p)
    return out


def macro_for_run(run_dir: str, panel: dict | None) -> dict | None:
    """Acierto por ítem del macro de T-gen para una corrida (promedio sobre los generadores del macro, en la
    intersección de ítems): eval/correct_tgenmacro[_shuf].npy. También "tgenall" (todos los primarios, sin el
    criterio de atajo; respaldo de §3.6). Si la corrida no tiene todo lo necesario, borra los archivos viejos
    del macro (nunca se usa un macro de otra versión del panel) y devuelve None."""
    ev = os.path.join(run_dir, "eval")
    if not panel or not panel.get("macro") or not panel.get("macro_items"):
        for nm in ("tgenmacro", "tgenall") + tuple(TIER_METRIC.values()):
            _clear_macro(ev, nm)
        return None
    sigs = {k: (panel["generators"].get(k) or {}).get("negs_sha") for k in panel.get("generators", {})}
    out = _macro(ev, panel["macro"], np.asarray(panel["macro_items"], np.int64), panel["version"], "tgenmacro", sigs)
    if panel.get("todos") and panel.get("todos_items"):
        _macro(ev, panel["todos"], np.asarray(panel["todos_items"], np.int64), panel["version"] + "-todos", "tgenall", sigs)
    for t, nm in TIER_METRIC.items():
        sub = (panel.get("macro_por_tamano") or {}).get(t) or {}
        if sub.get("keys") and sub.get("items"):
            _macro(ev, sub["keys"], np.asarray(sub["items"], np.int64), f"{panel['version']}-{t}", nm, sigs)
        else:
            _clear_macro(ev, nm)
    return out


def export_qc(study, split: str = "test", keys: list | None = None, n_items: int = 20, seed: int = 0) -> str | None:
    """CSV para revisar falsos negativos a mano (criterio de DISENO_01: < 5 %): n_items × 10 por generador."""
    import pandas as pd
    root = tgen_root(study, split)
    texts = {r["i"]: r for r in read_jsonl(os.path.join(root, "items_text.jsonl")) if not r.get("missing")}
    rows = []
    for k in keys or sorted(d for d in os.listdir(root) if os.path.isdir(os.path.join(root, d))):
        kept = read_jsonl(os.path.join(root, k, "kept.jsonl"))
        if not kept:
            continue
        pick = np.random.default_rng(seed).choice(len(kept), size=min(n_items, len(kept)), replace=False)
        sub = []
        for j in sorted(pick):
            r = kept[int(j)]
            t = texts.get(r["i"], {})
            for neg, c in zip(r["negatives"], r["cos_to_gold"]):
                sub.append({"generador": k, "item": r["i"], "pregunta": t.get("question"), "oro": t.get("answer"),
                            "negativo": neg, "coseno_al_oro": round(c, 3), "es_correcta(0/1)": "", "notas": ""})
        pd.DataFrame(sub).to_csv(os.path.join(root, k, "QC_falsos_negativos.csv"), index=False)
        rows += sub
    if not rows:
        return None
    p = os.path.join(root, "QC_falsos_negativos_panel.csv")
    pd.DataFrame(rows).to_csv(p, index=False)
    return p


def panel_table(study, split: str = "test"):
    """Tabla del panel para el notebook."""
    import pandas as pd
    panel = load_panel(study, split) or {}
    rows = []
    for k, g in (panel.get("generators") or {}).items():
        aud = load_json(os.path.join(gen_dir(study, k, split), "audit.json")) or {}
        emb = load_json(os.path.join(gen_dir(study, k, split), "embed_info.json")) or {}
        info = load_json(os.path.join(gen_dir(study, k, split), "gen_info.json")) or {}
        rows.append({"generador": k, "familia": g.get("family"), "rol": ROLE_TXT.get(g.get("role"), g.get("role")),
                     "tamaño": g.get("tier"), "estado": g.get("status"), "ítems": g.get("items"),
                     "descartados_por_parecerse_al_oro": emb.get("negatives_removed_fn"),
                     "más_larga": aud.get("longest"), "más_corta": aud.get("shortest"),
                     "ciego_Gemini": aud.get("blind_gemini"), "ciego_propio": aud.get("blind_own_cv"),
                     "coseno_crudo": aud.get("raw_cosine"), "atajo_ciego": aud.get("atajo_ciego"),
                     "banda": aud.get("banda"), "en_macro": g.get("in_macro"),
                     "min_generación": round(float(info.get("seconds_total", 0)) / 60, 1) if info else None})
    return pd.DataFrame(rows)


def panel_summary(study) -> dict:
    """Descripción del panel (para la celda y los documentos)."""
    return {g.key: {k: v for k, v in asdict(g).items() if k != "key"} for g in PANEL}


# --------------------------------------------------------------------------------------
# Panel sintético (perfil smoke y pruebas): mismos archivos, sin LLM
def synthetic_panel(study, test, split: str = "test", n_items: int = 300, specs=None, seed: int = 0) -> list:
    """Generadores sintéticos con artefactos de distinta fuerza (en el espacio de embedding y en la longitud),
    para probar auditoría, macro, evaluación y estadística. No dice nada sobre generadores reales."""
    from .data import _l2
    specs = specs or [("syn_limpio", "primario", 0.0, 0.0), ("syn_debil", "primario", 0.08, 0.0),
                      ("syn_largo", "primario", 0.0, 0.6), ("syn_fuerte", "primario", 0.6, 0.0),
                      ("syn_control", "control_qwen", 0.0, 0.0)]
    syn_tier = {"syn_limpio": "grande", "syn_debil": "chico", "syn_largo": "grande", "syn_fuerte": "chico"}
    pre_root = study.paths.c("synthetic", "pre")
    shard = study.data.shard
    info = load_json(os.path.join(pre_root, shard, "SYNTHETIC.json"))
    Wa = np.load(os.path.join(pre_root, shard, "W_a.npy"))
    man = load_json(os.path.join(test.dir, "manifest.json"))
    lat = []
    for c in man["chunks"]:
        rows = load_json(os.path.join(test.dir, f"c{c:04d}_meta.json"))["row"]
        lat.append(np.load(os.path.join(pre_root, shard, f"chunk_{c:04d}_latent.npy"))[rows])
    lat = np.concatenate(lat)
    sub = os.path.join(test.dir, "subsample.npy")
    if os.path.exists(sub):
        lat = lat[np.load(sub)]
    order = panel_order(study, test, split)
    items = np.sort(order[:n_items])
    lp = os.path.join(study.paths.d("data", "eval", split), "lengths.npz")
    gold_len = np.load(lp)["gold"] if os.path.exists(lp) else None
    made = []
    for j, (key, role, art, len_bias) in enumerate(specs):
        gd = makedirs(gen_dir(study, key, split))
        if os.path.exists(os.path.join(gd, "negs.npy")):
            made.append(key)
            continue
        rs = np.random.default_rng(seed + 101 * (j + 1))
        v = _l2(rs.standard_normal(Wa.shape[1]))
        delta = rs.standard_normal((len(items), K_KEEP, info["latent"])).astype(np.float32)
        n = _l2((lat[items][:, None, :] + info["hardness"] * delta) @ Wa
                + info["noise"] * rs.standard_normal((len(items), K_KEEP, Wa.shape[1])) + art * v)
        atomic_np_save(items.astype(np.int64), os.path.join(gd, "items.npy"))
        atomic_np_save(n.astype(np.float16), os.path.join(gd, "negs.npy"))
        base = gold_len[items] if gold_len is not None else rs.integers(10, 60, len(items))
        nt = np.maximum(1, (base[:, None] * (1 - len_bias) + rs.integers(-6, 7, (len(items), K_KEEP)))).astype(np.int32)
        atomic_np_save(nt, os.path.join(gd, "neg_tokens.npy"))
        with open(os.path.join(gd, "kept.jsonl"), "w") as f:
            for i in items:
                f.write(json.dumps({"i": int(i), "negatives": [f"{key} negativo {t}" for t in range(K_KEEP)],
                                    "cos_to_gold": [0.5] * K_KEEP}) + "\n")
        save_json({"key": key, "role": role, "family": "sintético", "repo": None, "status": "generado",
                   "artifact": art, "len_bias": len_bias, "items_requested": int(len(items)),
                   "tier": syn_tier.get(key)},
                  os.path.join(gd, "gen_info.json"))
        save_json({"key": key, "items_kept": int(len(items)), "items_requested": int(len(items)),
                   "negatives_removed_fn": 0, "negs_sha": content_sha(n.astype(np.float16), items)},
                  os.path.join(gd, "embed_info.json"))
        made.append(key)
    tpath = os.path.join(tgen_root(study, split), "items_text.jsonl")
    if not os.path.exists(tpath):
        with open(tpath, "w") as f:
            for i in items:
                f.write(json.dumps({"i": int(i), "question": f"pregunta {i}", "answer": f"oro {i}", "gold_tokens": 20}) + "\n")
    return made
