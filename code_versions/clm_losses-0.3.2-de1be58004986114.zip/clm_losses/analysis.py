"""Análisis de la enmienda 03: uso del estado y transferencia entre generadores (EXP-006 y siguientes).

Lectura pre-especificada (ENMIENDA_03 §6), para un contraste A − B en el macro de T-gen:
    "transfiere"      Δ > +ROPE (1 pp) y el IC95 excluye 0
    "empeora"         Δ < −ROPE y el IC95 excluye 0
    "no transfiere"   equivalentes por TOST dentro de ±ROPE
    "no concluyente"  lo demás
Además se reporta la fracción transferida Δ(T-gen) / Δ(T-gem), sólo si los HN suben T-gem (Δ > ROPE, IC95 > 0).
Secundario (§10): el mismo contraste en el macro de generadores grandes y en el de chicos, y su interacción.
"""
from __future__ import annotations

import os

import numpy as np

from .generators import load_panel, macro_for_run
from .pipeline import iter_run_dirs
from .stats import clusters_from_docs, contrast
from .utils import load_json, makedirs, save_json

METRICS = ("tgem", "tgem_shuf", "tmine", "tmine_shuf", "trand", "tmine50", "tgenmacro", "tgenmacro_shuf",
           "tgenbig", "tgensmall", "tgenall", "tgenall_shuf")
LABELS = {"tgem": "T-gem", "tgem_shuf": "T-gem barajado", "tmine": "T-mine", "tmine_shuf": "T-mine barajado",
          "trand": "T-rand", "tmine50": "T-mine-50", "tgenmacro": "T-gen (macro)",
          "tgenmacro_shuf": "T-gen (macro) barajado", "tgenbig": "T-gen (macro de grandes, secundario)",
          "tgensmall": "T-gen (macro de chicos, secundario)",
          "tgenall": "T-gen (todos los primarios, con atajo; respaldo §3.6)",
          "tgenall_shuf": "T-gen (todos los primarios) barajado",
          "tgenfail": "T-gen, ítems donde el ciego propio falla (primarios; respaldo §3.6)",
          "tgenfail_shuf": "T-gen, ítems donde el ciego falla, barajado"}


def default_groups(study) -> dict:
    """Grupos de corridas: F0.7 y F1 piloto (ya entrenadas) y, si existen, F0.7b y F1b."""
    g = {}
    for lab, d in (("F0.7 · pre (sin HN)", "infonce_pre"), ("F0.7 · HN + in-batch", "infonce_hn_inbatch"),
                   ("F0.7 · HN solos", "infonce_hn_hnonly"), ("F0.7 · HN desde el inicio (sólo HN)", "infonce_hn_start")):
        rds = [r for r in iter_run_dirs(study, "F0.7") if f"/F0.7/{d}/" in r]
        if rds:
            g[lab] = rds
    for rec in ("clm", "actual"):
        for cond in ("pre", "mid_inbatch", "start_inbatch", "mid_hnonly"):
            rds = [r for r in iter_run_dirs(study, "F0.7b") if f"/F0.7b/{rec}/{cond}/" in r]
            if rds:
                g[f"F0.7b · {rec} · {cond}"] = rds
    for ph in ("F1", "F1b"):
        for arm in ("infonce", "infonce_hn", "siglip", "siglip_hn", "triplet_hn"):
            rds = [r for r in iter_run_dirs(study, ph) if f"/{ph}/{arm}/" in r]
            if rds:
                g[f"{ph} · {arm}"] = rds
    return g


DEFAULT_CONTRASTS = [
    ("F0.7 · HN + in-batch", "F0.7 · pre (sin HN)"),
    ("F0.7 · HN solos", "F0.7 · HN + in-batch"),
    ("F0.7 · HN desde el inicio (sólo HN)", "F0.7 · pre (sin HN)"),
    ("F1 · infonce_hn", "F1 · infonce"),
    ("F1 · siglip_hn", "F1 · siglip"),
    ("F0.7b · clm · mid_inbatch", "F0.7b · clm · pre"),
    ("F0.7b · actual · mid_inbatch", "F0.7b · actual · pre"),
    ("F0.7b · actual · mid_hnonly", "F0.7b · actual · mid_inbatch"),
    ("F1b · infonce_hn", "F1b · infonce"),
    ("F1b · siglip_hn", "F1b · siglip"),
]


def _load(rd: str, name: str):
    p = os.path.join(rd, "eval", f"correct_{name}.npy")
    return np.load(p).astype(np.float32) if os.path.exists(p) else None


def _stack(rds, name):
    xs = [_load(rd, name) for rd in rds]
    if any(x is None for x in xs):
        return None
    if len({len(x) for x in xs}) != 1:
        return None
    return np.vstack(xs)


def reading(c: dict, rope: float) -> str:
    if c["diff"] > rope and c["ci95_lo"] > 0:
        return "transfiere"
    if c["diff"] < -rope and c["ci95_hi"] < 0:
        return "empeora"
    if c["tost_equivalent"]:
        return "no transfiere (equivalente)"
    return "no concluyente"


def transfer_report(study, bundle, groups: dict | None = None, contrasts=None, out_name: str = "EXP006",
                    B: int = 2000, log=print) -> dict:
    """Tabla por grupo (métricas + cada generador del panel) y contrastes pareados por documento."""
    import pandas as pd
    panel = load_panel(study, bundle.test_split)
    groups = groups or default_groups(study)
    if panel:
        for rds in groups.values():
            for rd in rds:
                macro_for_run(rd, panel)
    gens = sorted((panel or {}).get("generators", {}))
    # subconjunto "el ciego propio falla" de cada generador (respaldo de §3.6): ítems donde la sonda ciega con
    # validación cruzada no acierta; alineado con items.npy del generador
    fail_mask = {}
    for k in gens:
        gd = os.path.join(study.paths.d("data", "eval", "tgen", bundle.test_split), k)
        pc, pi = os.path.join(gd, "blind_own_cv_correct.npy"), os.path.join(gd, "items.npy")
        if os.path.exists(pc) and os.path.exists(pi):
            fail_mask[k] = (np.load(pi), np.load(pc) < 0.5)
    prim = [k for k in (panel or {}).get("todos", [])]

    def fail_pool(rds, shuf=False):
        """Respaldo de §3.6: acierto en los pares (generador primario, ítem) donde el ciego propio de ese generador
        falla, concatenados; con el documento de cada ítem para el bootstrap. None si falta algo."""
        cols, docs = [], []
        for k in prim:
            if k not in fail_mask:
                continue
            X = _stack(rds, f"tgen_{k}" + ("_shuf" if shuf else ""))
            if X is None:
                return None, None
            it_run = np.load(os.path.join(rds[0], "eval", f"items_tgen_{k}.npy"))
            it_gen, mask = fail_mask[k]
            if not np.array_equal(it_run, it_gen):
                return None, None
            cols.append(X[:, mask])
            docs.append(np.asarray(bundle.test.doc_ids)[it_gen[mask]])
        if not cols:
            return None, None
        return np.concatenate(cols, 1), np.concatenate(docs)

    rows = []
    for lab, rds in groups.items():
        row = {"grupo": lab, "semillas": len(rds)}
        for m in METRICS:
            X = _stack(rds, m)
            row[LABELS[m]] = round(float(X.mean()), 4) if X is not None else None
        for nm, sh in (("tgenfail", False), ("tgenfail_shuf", True)):
            X, _ = fail_pool(rds, sh)
            row[LABELS[nm]] = round(float(X.mean()), 4) if X is not None else None
        for k in gens:
            X = _stack(rds, f"tgen_{k}")
            row[f"{k}"] = round(float(X.mean()), 4) if X is not None else None
            Xs = _stack(rds, f"tgen_{k}_shuf")
            row[f"{k} (barajado)"] = round(float(Xs.mean()), 4) if Xs is not None else None
            if X is not None and k in fail_mask:
                it_run = np.load(os.path.join(rds[0], "eval", f"items_tgen_{k}.npy"))
                it_gen, mask = fail_mask[k]
                if np.array_equal(it_run, it_gen) and mask.any():
                    row[f"{k} (ciego propio falla)"] = round(float(X[:, mask].mean()), 4)
        rows.append(row)
    table = pd.DataFrame(rows)
    rope = study.rope_pp / 100
    doc = np.asarray(bundle.test.doc_ids)
    cl_all = clusters_from_docs(doc)
    eff = []
    for a, b in (contrasts or DEFAULT_CONTRASTS):
        if a not in groups or b not in groups:
            continue
        mets = (["tgem", "tgem_shuf", "tmine", "tgenmacro", "tgenmacro_shuf", "tgenbig", "tgensmall", "tgenall",
                 "tgenall_shuf", "tgenfail", "tgenfail_shuf"] + [f"tgen_{k}" for k in gens])
        d_tgem = None
        for m in mets:
            if m.startswith("tgenfail"):
                (A, dA), (Bm, dB) = fail_pool(groups[a], m.endswith("_shuf")), fail_pool(groups[b], m.endswith("_shuf"))
                if A is None or Bm is None or A.shape[1] != Bm.shape[1]:
                    continue
                c = contrast(A, Bm, clusters_from_docs(dA), rope, B=B)
                eff.append({"contraste": f"{a} − {b}", "métrica": LABELS[m], "Δ (pp)": round(100 * c["diff"], 1),
                            "IC95 (pp)": f"[{100 * c['ci95_lo']:.1f}, {100 * c['ci95_hi']:.1f}]", "p": c["p"],
                            "TOST ±1 pp": c["tost_equivalent"],
                            "lectura": reading(c, rope) + " (respaldo §3.6)" if m == "tgenfail" else ""})
                continue
            A, Bm = _stack(groups[a], m), _stack(groups[b], m)
            if A is None or Bm is None or A.shape[1] != Bm.shape[1]:
                continue
            if m.startswith("tgen"):
                it = None
                if m.startswith("tgenmacro") and panel:
                    it = np.asarray(panel["macro_items"], np.int64)
                elif m.startswith("tgenall") and panel:
                    it = np.asarray(panel.get("todos_items") or [], np.int64)
                else:
                    pi = os.path.join(groups[a][0], "eval", f"items_{m.replace('_shuf', '')}.npy")
                    it = np.load(pi) if os.path.exists(pi) else None
                cl = clusters_from_docs(doc[it]) if it is not None and len(it) == A.shape[1] else np.arange(A.shape[1])
            else:
                cl = cl_all
            c = contrast(A, Bm, cl, rope, B=B)
            r = {"contraste": f"{a} − {b}", "métrica": LABELS.get(m, m), "Δ (pp)": round(100 * c["diff"], 1),
                 "IC95 (pp)": f"[{100 * c['ci95_lo']:.1f}, {100 * c['ci95_hi']:.1f}]", "p": c["p"],
                 "TOST ±1 pp": c["tost_equivalent"]}
            if m == "tgem" and c["diff"] > rope and c["ci95_lo"] > 0:
                d_tgem = c["diff"]          # la fracción sólo tiene sentido si los HN sí suben T-gem
            if m == "tgenmacro":
                r["lectura"] = reading(c, rope)
                if d_tgem:
                    r["fracción transferida"] = round(c["diff"] / d_tgem, 2)
            elif m in ("tgenbig", "tgensmall"):
                r["lectura"] = reading(c, rope) + " (secundario)"
            elif m == "tgenall":
                r["lectura"] = reading(c, rope) + " (con atajo; respaldo §3.6)"
            eff.append(r)
        # secundario (ENMIENDA_03 §10): ¿el efecto A − B cambia con el tamaño del generador? Interacción
        # (A − B en el macro de grandes) − (A − B en el macro de chicos), en los ítems comunes a los dos macros.
        Ab, Bb, As_, Bs_ = (_stack(groups[g], m) for g, m in ((a, "tgenbig"), (b, "tgenbig"),
                                                               (a, "tgensmall"), (b, "tgensmall")))
        if all(x is not None for x in (Ab, Bb, As_, Bs_)):
            ib = np.load(os.path.join(groups[a][0], "eval", "items_tgenbig.npy"))
            ism = np.load(os.path.join(groups[a][0], "eval", "items_tgensmall.npy"))
            common = np.intersect1d(ib, ism)
            if len(common) >= 20 and Ab.shape[1] == len(ib) and As_.shape[1] == len(ism):
                pb, ps = np.searchsorted(ib, common), np.searchsorted(ism, common)
                c = contrast(Ab[:, pb] - As_[:, ps], Bb[:, pb] - Bs_[:, ps], clusters_from_docs(doc[common]), rope, B=B)
                eff.append({"contraste": f"{a} − {b}", "métrica": "interacción: efecto en grandes − efecto en chicos",
                            "Δ (pp)": round(100 * c["diff"], 1),
                            "IC95 (pp)": f"[{100 * c['ci95_lo']:.1f}, {100 * c['ci95_hi']:.1f}]", "p": c["p"],
                            "TOST ±1 pp": c["tost_equivalent"],
                            "lectura": f"secundario ({len(common)} ítems comunes)"})
    effects = pd.DataFrame(eff)
    out = makedirs(study.paths.d("results", "transfer", out_name))
    table.to_csv(os.path.join(out, "tabla.csv"), index=False)
    effects.to_csv(os.path.join(out, "contrastes.csv"), index=False)
    save_json({"panel_version": (panel or {}).get("version"), "panel_macro": (panel or {}).get("macro"),
               "panel_build": (panel or {}).get("build"), "panel_todos": (panel or {}).get("todos"),
               "tabla": rows, "contrastes": eff, "rope_pp": study.rope_pp,
               "lectura": "transfiere: Δ macro > +ROPE con IC95 > 0; no transfiere: TOST ±ROPE; si no, no concluyente"},
              os.path.join(out, "transfer.json"))
    log(f"[transfer] guardado en {out}")
    return {"tabla": table, "contrastes": effects, "dir": out}


def state_use_table(study, phase: str = "F1b"):
    """Por brazo (media de semillas): acierto con estados reales y barajados (A1.4) en T-mine, T-gem y el macro
    de T-gen, y abstención en T-abst-mine. "Uso del estado" = real − barajado."""
    import pandas as pd
    from .losses import ARMS, arm_names
    panel = load_panel(study, "confirm" if phase == "F3" else "test")
    rows = []
    for arm in arm_names():
        rds = [r for r in iter_run_dirs(study, phase) if f"/{phase}/{arm}/" in r]
        if not rds:
            continue
        acc = {}
        for rd in rds:
            m = load_json(os.path.join(rd, "eval", "metrics.json"), {}) or {}
            mac = macro_for_run(rd, panel) if panel else None
            vals = {"T-mine": (m.get("tmine") or {}).get("top1"), "T-mine barajado": (m.get("tmine_shuf") or {}).get("top1"),
                    "T-gem": (m.get("tgem") or {}).get("top1"), "T-gem barajado": (m.get("tgem_shuf") or {}).get("top1"),
                    "T-gen macro": (mac or {}).get("top1"), "T-gen macro barajado": (mac or {}).get("shuf_top1"),
                    "AUROC T-abst-mine": (m.get("tabst_mine") or {}).get("abst_auroc_maxcos")}
            for k, v in vals.items():
                if v is not None:
                    acc.setdefault(k, []).append(v)
        row = {"#": ARMS[arm]["num"], "brazo": arm, "semillas": len(rds)}
        row.update({k: round(float(np.mean(v)), 4) for k, v in acc.items()})
        if "T-gem" in row and "T-gem barajado" in row:
            row["uso del estado T-gem (pp)"] = round(100 * (row["T-gem"] - row["T-gem barajado"]), 1)
        if "T-gen macro" in row and "T-gen macro barajado" in row:
            row["uso del estado T-gen (pp)"] = round(100 * (row["T-gen macro"] - row["T-gen macro barajado"]), 1)
        rows.append(row)
    return pd.DataFrame(rows).sort_values("#") if rows else pd.DataFrame()


def f07b_table(study):
    """Tabla de F0.7b: una fila por receta × condición (media de semillas)."""
    import pandas as pd
    res = load_json(study.paths.d("f0", "F0.7b_recipes", "result.json")) or {}
    acc = {}
    for key, r in (res.get("runs") or {}).items():
        rec, cond, _ = key.split("/")
        acc.setdefault((rec, cond), []).append(r)
    rows = []
    for (rec, cond), lst in sorted(acc.items()):
        row = {"receta": rec, "condición": cond, "semillas": len(lst)}
        for k in ("tmine", "tmine_shuf", "tgem", "tgem_shuf", "trand", "tmine50", "abst_tmine", "val_best"):
            xs = [x.get(k) for x in lst if x.get(k) is not None]
            row[k] = round(float(np.mean(xs)), 4) if xs else None
        secs = [x.get("train_seconds") for x in lst if x.get("train_seconds") is not None]
        row["min_entrenamiento"] = round(float(np.mean(secs)) / 60, 1) if secs else None
        rows.append(row)
    return pd.DataFrame(rows), res.get("G2b")
