"""clm_losses: comparación controlada de funciones de pérdida para scorers estado→acción
sobre un LLM congelado (tipo CLM-8B).

Estructura:
    config    rutas (Drive / caché local), perfiles de datos, hiperparámetros por defecto
    utils     guardado atómico, registro de corridas, semillas, entorno
    heads     cabezales idénticos a CLM (servibles con clm-serve)
    losses    las 15 pérdidas + modelo ciego + término auxiliar de HN
    data      stores de embeddings (HF o sintéticos), splits por documento, streams reanudables
    train     entrenador con checkpoints y reanudación exacta
    evaluate  top-1, abstención, calibración, geometría
    stats     todos-contra-todos (bootstrap por documento, Holm, TOST, Friedman/Nemenyi)
    hpo       búsqueda aleatoria reanudable + curvas de desempeño esperado vs presupuesto
    encoder   Qwen3-8B (transformers o vLLM), last-token pooling
    texts     tokens de Nemotron: textos, longitudes, negativos minados / generados
    f0        pasos y compuertas de F0
    trex      T-Rex con y sin shield (arnés de CLM)
    deepswe   verificación de identidad del set de evaluación de DeepSWE
    pipeline  funciones de alto nivel que llama cada celda del notebook
"""
__version__ = "0.2.0"
