"""F0: compuerta antes de cualquier comparación. Cada paso guarda su resultado en
Drive (<perfil>/f0/F0.x_*/result.json) y, si ya existe, no se repite."""
from __future__ import annotations

import hashlib
import os

import numpy as np
import torch

from .config import (CLM_HEAD_REPO, CLM_STAGE_HEADS_REPO, DEEPSWE_HEADS_REPO, HN_REPO, PRETRAIN_REPO,
                     TOKENS_REPO)
from .data import (EvalSet, HFDownloader, Split, build_split, check_alignment, extract_eval_set, hn_name,
                   pre_name, slug, train_masks)
from .evaluate import build_pool_indices, cos_matrix, geometry, quick_val, rank_metrics
from .heads import heads_from_clm_checkpoint, load_torch
from .losses import BlindScorer
from .pipeline import base_cfg, extra_sets, load_bundle, make_store, run_one
from .utils import atomic_torch_save, load_json, makedirs, rng, save_json

# Umbrales de las compuertas (P4): fijarlos ANTES de correr F0.
GATES = {
    "G1_cos_median": 0.999, "G1_cos_p01": 0.995,
    "G2_tol_pp": 3.0, "G2_ref": {"pre": 0.521, "mid": 0.692, "start_peak": 0.624},
    "G3_bands": (0.15, 0.30),
    "G4_rankme_frac": 0.05, "G4_rand_margin": 0.02,
    "G5_ref_agreement": 0.658, "G5_tol": 0.05,
}


def _out(study, name: str) -> str:
    return makedirs(study.paths.d("f0", name))


def _cached(path: str):
    return load_json(path) if os.path.exists(path) else None


# --------------------------------------------------------------------------------------
def f0_1_checkpoints(study, log=print) -> dict:
    """Carga los cabezales públicos: cfg, parámetros, logit_scale, sha256."""
    out = _out(study, "F0.1_checkpoints")
    res_p = os.path.join(out, "result.json")
    if (r := _cached(res_p)) is not None:
        return r
    from huggingface_hub import hf_hub_download
    targets = [(CLM_HEAD_REPO, "CLM_v0.1-8B.pt"), (CLM_STAGE_HEADS_REPO, "qwen3_8b_pretrained_head.pt"),
               (CLM_STAGE_HEADS_REPO, "qwen3_8b_midtrained_head.pt"),
               (CLM_STAGE_HEADS_REPO, "qwen3_8b_posttrained_head.pt"), (DEEPSWE_HEADS_REPO, "best_head.pt")]
    res = {"heads": {}}
    for repo, fn in targets:
        path = hf_hub_download(repo, fn, local_dir=study.paths.c("hf", slug(repo)))
        h = hashlib.sha256()
        with open(path, "rb") as f:
            for blk in iter(lambda: f.read(1 << 22), b""):
                h.update(blk)
        entry = {"path": path, "bytes": os.path.getsize(path), "sha256": h.hexdigest()}
        try:
            ck = load_torch(path)
            heads = heads_from_clm_checkpoint(ck)
            entry.update(cfg_in_file=ck.get("cfg"), cfg_effective=heads.cfg, n_params=heads.n_params(),
                         logit_scale=float(heads.logit_scale), scale=float(heads.scale()))
        except Exception as e:
            entry["error"] = str(e)
        res["heads"][f"{repo}/{fn}"] = entry
        log(f"[F0.1] {repo}/{fn}: {entry.get('cfg_effective')} params={entry.get('n_params')}")
    ours = study.train
    ref = res["heads"].get(f"{CLM_HEAD_REPO}/CLM_v0.1-8B.pt", {}).get("cfg_effective") or {}
    res["matches_our_arch"] = bool(ref) and all(ref.get(k) == v for k, v in (
        ("width", ours.width), ("depth", ours.depth), ("projection_dim", ours.proj), ("layernorm", ours.layernorm)))
    save_json(res, res_p)
    return res


def f0_2_manifest(study, log=print) -> dict:
    """Tamaños y sha256 (según HF) de cada archivo que usará el perfil + licencias conocidas."""
    out = _out(study, "F0.2_manifest")
    res_p = os.path.join(out, "DATA_MANIFEST.json")
    if (r := _cached(res_p)) is not None:
        return r
    d = study.data
    dl = HFDownloader()
    pre = [pre_name(d.shard, c, k) for c in sorted(set(d.pre_chunks) | set(d.hn_chunks)) for k in ("q", "a", "meta")]
    hn = [hn_name(d.shard, c, k) for c in d.hn_chunks for k in ("n", "ncnt", "nmeta")]
    from .texts import NEG_PARTS, QA_PARTS
    man = {"created": __import__("datetime").datetime.now().isoformat(timespec="seconds"),
           "repos": {PRETRAIN_REPO: dl.remote_info(PRETRAIN_REPO, pre), HN_REPO: dl.remote_info(HN_REPO, hn),
                     TOKENS_REPO: dl.remote_info(TOKENS_REPO, QA_PARTS + NEG_PARTS)},
           "licenses_known": {
               PRETRAIN_REPO: "sin licencia declarada (2026-09-30)",
               HN_REPO: "sin verificar", TOKENS_REPO: "nvidia-open-data-license; dice regirse por Nemotron-CC-v2.1 (gated)",
               "nvidia/Nemotron-CC-v2.1": "acuerdo NVIDIA para entrenamiento de modelos; no redistribuir"},
           "note": "No redistribuir datos derivados de Nemotron sin revisar la licencia [AUTHOR DECISION NEEDED]."}
    total = sum((v.get("size") or 0) for repo in man["repos"].values() for v in repo.values())
    man["total_gb_listed"] = round(total / 1e9, 1)
    save_json(man, res_p)
    log(f"[F0.2] manifiesto: {man['total_gb_listed']} GB listados")
    return man


def f0_download(study, log=print) -> dict:
    from .pipeline import resources
    r = resources(study)
    log(f"[descarga] {r}")
    if not r["alcanza"] and not study.data.synthetic:
        raise RuntimeError(f"no hay disco suficiente: {r}")
    store = make_store(study)
    store.ensure(sorted(set(study.data.pre_chunks) | set(study.data.hn_chunks)), study.data.hn_chunks, log=log)
    return r


def f0_3_embedding_equivalence(study, n: int = 2000, n_neg_items: int = 100, backend: str = "hf", log=print) -> dict:
    """G1: nuestro pipeline de embeddings reproduce los embeddings públicos (q, a y el orden de los HN)."""
    out = _out(study, "F0.3_embeddings")
    res_p = os.path.join(out, "result.json")
    if (r := _cached(res_p)) is not None:
        return r
    from .encoder import make_encoder
    from .texts import lookup
    store = make_store(study)
    c = study.data.hn_chunks[0]
    ids, pidx = store.meta(c)
    rows = np.sort(rng(7, c).choice(len(ids), size=min(n, len(ids)), replace=False))
    docs = set(ids[rows].tolist())
    qa = {(r["doc_id"], r["pair_idx"]): r for r in lookup(study.paths, docs, "qa",
                                                          ["doc_id", "pair_idx", "question_ids", "answer_ids"])}
    keep = [r for r in rows if (ids[r], int(pidx[r])) in qa]
    enc = make_encoder(backend)
    Eq = enc.embed_ids([qa[(ids[r], int(pidx[r]))]["question_ids"] for r in keep])
    Ea = enc.embed_ids([qa[(ids[r], int(pidx[r]))]["answer_ids"] for r in keep])

    def cmp(E, ref):
        ref = np.asarray(ref, np.float32)
        ref /= np.linalg.norm(ref, axis=1, keepdims=True) + 1e-12
        cs = (E * ref).sum(1)
        return {"median": float(np.median(cs)), "p01": float(np.quantile(cs, 0.01)), "min": float(cs.min()),
                "mean": float(cs.mean())}
    res = {"backend": backend, "n": len(keep), "chunk": int(c),
           "q": cmp(Eq, store.q(c)[keep]), "a": cmp(Ea, store.a(c)[keep])}
    # orden de los negativos: ¿el k-ésimo embedding corresponde a neg_idx = k?
    sub = [r for r in keep[:n_neg_items] if store.ncnt(c)[r] >= 10]
    negs = {}
    for r in lookup(study.paths, {ids[x] for x in sub}, "neg", ["doc_id", "pair_idx", "neg_idx", "neg_ids"]):
        negs.setdefault((r["doc_id"], r["pair_idx"]), {})[r["neg_idx"]] = r["neg_ids"]
    same, best = [], []
    for r in sub:
        m = negs.get((ids[r], int(pidx[r])), {})
        if len(m) < 10:
            continue
        E = enc.embed_ids([m[j] for j in sorted(m)][:10])
        ref = np.asarray(store.n(c)[r, :10], np.float32)
        ref /= np.linalg.norm(ref, axis=1, keepdims=True) + 1e-12
        S = E @ ref.T
        same.append(float(np.diag(S).mean()))
        best.append(float(S.max(1).mean()))
    res["neg_order"] = {"items": len(same), "diag_cos_mean": float(np.mean(same)) if same else None,
                        "best_match_cos_mean": float(np.mean(best)) if best else None}
    ok = all(res[k]["median"] >= GATES["G1_cos_median"] and res[k]["p01"] >= GATES["G1_cos_p01"] for k in ("q", "a"))
    res["G1_pass"] = bool(ok)
    save_json(res, res_p)
    log(f"[F0.3] G1={'PASA' if ok else 'NO PASA'} q={res['q']} a={res['a']} negs={res['neg_order']}")
    return res


def f0_4_splits(study, log=print) -> dict:
    out = _out(study, "F0.4_splits")
    res_p = os.path.join(out, "result.json")
    if (r := _cached(res_p)) is not None:
        return r
    store = make_store(study)
    d = study.data
    sdir = study.paths.d("data", "splits")
    split = build_split(store, d, sdir, log=log)
    align = [check_alignment(store, c) for c in d.hn_chunks]
    mp = train_masks(store, split, d.pre_chunks, sdir, "pre")
    mm = train_masks(store, split, d.hn_chunks, sdir, "mid")
    # fuga: ningún documento de test/val puede quedar en filas de entrenamiento
    hold = split.holdout()
    leaks = 0
    for c in d.pre_chunks:
        ids, _ = store.meta(c)
        leaks += int(sum(1 for i in np.nonzero(mp[c])[0] if ids[i] in hold))
    res = {"test_docs": len(split.test_docs), "val_docs": len(split.val_docs),
           "train_rows_pre": int(sum(m.sum() for m in mp.values())),
           "train_rows_mid": int(sum(m.sum() for m in mm.values())), "alignment": align,
           "all_aligned": all(a["aligned"] for a in align), "leaked_rows": leaks}
    save_json(res, res_p)
    log(f"[F0.4] {res}")
    return res


def f0_5_eval_sets(study, lengths: bool = True, qc: bool = True, log=print) -> dict:
    out = _out(study, "F0.5_eval_sets")
    res_p = os.path.join(out, "result.json")
    if (r := _cached(res_p)) is not None:
        return r
    store = make_store(study)
    d, p = study.data, study.paths
    split = Split.load(p.d("data", "splits"))
    tdir, vdir, cdir = p.d("data", "eval", "test"), p.d("data", "eval", "val"), p.d("data", "eval", "confirm")
    mt = extract_eval_set(store, split, "test", d.hn_chunks, tdir, k=d.k_neg, max_items=d.n_test_max,
                          max_per_doc=d.max_per_doc, log=log)
    mv = extract_eval_set(store, split, "val", d.hn_chunks, vdir, k=d.k_neg, max_items=d.n_val,
                          max_per_doc=d.max_per_doc, log=log)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    test = EvalSet(tdir)
    build_pool_indices(test, tdir, study.eval.n_rand, study.eval.n_mine, study.eval.mine_fn_threshold, device=dev)
    res = {"test": {"items": test.n, "docs": int(len(set(test.doc_ids.tolist()))), **mt},
           "val": {"items": EvalSet(vdir).n, **mv}}
    if d.confirm_frac > 0:
        # Test confirmatorio: se extrae ahora (los chunks de HN están en disco) pero queda SELLADO:
        # load_bundle(test_split="confirm") exige PROTOCOL_FREEZE.json. Aquí sólo se cuentan ítems.
        mc = extract_eval_set(store, split, "confirm", d.hn_chunks, cdir, k=d.k_neg, max_items=d.n_confirm_max,
                              max_per_doc=d.max_per_doc, log=log)
        conf = EvalSet(cdir)
        build_pool_indices(conf, cdir, study.eval.n_rand, study.eval.n_mine, study.eval.mine_fn_threshold,
                           device=dev)
        res["confirm_sealed"] = {"items": conf.n, **mc}
        del conf
    sims = np.load(os.path.join(tdir, "mine_sims.npy"))
    res["tmine_cos_to_gold"] = {"mean": float(sims.mean()), "p90": float(np.quantile(sims, 0.9))}
    if lengths and not d.synthetic:
        from .texts import eval_lengths, export_qc_sample
        eval_lengths(p, test, os.path.join(tdir, "lengths.npz"), log=log)
        eval_lengths(p, EvalSet(vdir), os.path.join(vdir, "lengths.npz"), log=log)
        res["lengths"] = True
        if qc:
            res["qc_csv"] = export_qc_sample(p, test, os.path.join(out, "QC_negativos_gemini.csv"))
    save_json(res, res_p)
    log(f"[F0.5] test={res['test']['items']} val={res['val']['items']}")
    return res


# --------------------------------------------------------------------------------------
def _cands(q, a, n):
    return np.concatenate([a[:, None, :], n], 1)


def train_blind(bundle, out_dir: str, epochs: float = 1.0, batch: int = 512, lr: float = 1e-3,
                seed: int = 0, min_steps: int = 300, log=print) -> BlindScorer:
    """Modelo ciego: sólo ve las acciones (oro + HN), nunca el estado."""
    from .data import Stream
    p = os.path.join(out_dir, "blind.pt")
    dev = torch.device("cuda" if torch.cuda.is_available() else "cpu")
    torch.manual_seed(seed)
    model = BlindScorer(bundle.hidden).to(dev)
    if os.path.exists(p):
        model.load_state_dict(torch.load(p, map_location=dev))
        return model.eval()
    d = bundle.dcfg
    n_rows = int(sum(m.sum() for m in bundle.masks_mid.values()))
    batch = int(min(batch, max(32, n_rows // 40)))
    st = Stream(bundle.store, d.hn_chunks, bundle.masks_mid, batch, d.mid_block_rows, d.mid_group_blocks,
                seed=seed + 11, with_hn=True, k=d.k_neg)
    total = max(min_steps, int(epochs * st.epoch_batches(0)))
    opt = torch.optim.AdamW(model.parameters(), lr=lr)
    step, ep = 0, 0
    while step < total:
        for b in st.iterate(ep):
            c = torch.from_numpy(_cands(None, b["ea"], b["en"])).float().to(dev)
            K = c.shape[1] - 1
            valid = torch.cat([torch.ones(len(c), 1, dtype=torch.bool),
                               torch.arange(K)[None] < torch.from_numpy(b["ncnt"]).long()[:, None]], 1).to(dev)
            s = model(c).masked_fill(~valid, -1e9)
            loss = torch.nn.functional.cross_entropy(s, torch.zeros(len(c), dtype=torch.long, device=dev))
            opt.zero_grad()
            loss.backward()
            opt.step()
            step += 1
            if step % 200 == 0:
                log(f"[blind] {step}/{total} loss={float(loss.detach()):.4f}")
            if step >= total:
                break
        ep += 1
    atomic_torch_save(model.state_dict(), p)
    return model.eval()


@torch.no_grad()
def blind_top1(model, evalset, cand_fn=None, bs: int = 1024) -> np.ndarray:
    dev = next(model.parameters()).device
    out = []
    for sel, q, a, n in evalset.iter_batches(bs):
        c = _cands(q, a, n) if cand_fn is None else cand_fn(sel, a)
        s = model(torch.from_numpy(c).float().to(dev)).cpu().numpy()
        out.append(s)
    S = np.concatenate(out)
    return rank_metrics(S)[1]


def f0_6_shortcuts(study, bundle=None, log=print) -> dict:
    """G3: ¿se puede acertar sin mirar el estado? Modelo ciego + heurística de longitud."""
    out = _out(study, "F0.6_shortcuts")
    res_p = os.path.join(out, "result.json")
    if (r := _cached(res_p)) is not None:
        return r
    bundle = bundle or load_bundle(study)
    model = train_blind(bundle, out, log=log)
    test = bundle.test
    res = {"chance": 1 / (1 + study.data.k_neg), "blind": {}}
    res["blind"]["tgem"] = float(blind_top1(model, test).mean())
    A = test.a_all()
    for name, fn in (("trand", "rand_idx.npy"), ("tmine", "mine_idx.npy")):
        pth = os.path.join(bundle.pools_dir, fn)
        if os.path.exists(pth):
            I = np.load(pth)
            res["blind"][name] = float(blind_top1(model, test, cand_fn=lambda sel, a: np.concatenate(
                [a[:, None, :], A[I[sel]]], 1)).mean())
    ex = extra_sets(bundle)
    if "tgen2" in ex:
        items, negs = ex["tgen2"]
        with torch.no_grad():
            dev = next(model.parameters()).device
            c = np.concatenate([A[items][:, None, :], np.asarray(negs)], 1)
            S = np.concatenate([model(torch.from_numpy(c[s:s + 1024]).float().to(dev)).cpu().numpy()
                                for s in range(0, len(c), 1024)])
        res["blind"]["tgen2"] = float(rank_metrics(S)[1].mean())
    # línea base sin entrenamiento: coseno crudo del encoder (cuánto aportan los cabezales)
    from .evaluate import raw_cosine_scores
    res["raw_cosine"] = {"tgem": rank_metrics(raw_cosine_scores(test, "tgem"))[0]["top1"]}
    for name, fn in (("trand", "rand_idx.npy"), ("tmine", "mine_idx.npy")):
        pth = os.path.join(bundle.pools_dir, fn)
        if os.path.exists(pth):
            res["raw_cosine"][name] = rank_metrics(raw_cosine_scores(test, "pool", pool_idx=np.load(pth)))[0]["top1"]
    if "tgen2" in ex:
        items, negs = ex["tgen2"]
        res["raw_cosine"]["tgen2"] = rank_metrics(raw_cosine_scores(test, "external", items=items,
                                                                    negs=np.asarray(negs)))[0]["top1"]
    lp_t = os.path.join(study.paths.d("data", "eval", "test"), "lengths.npz")
    lp_v = os.path.join(study.paths.d("data", "eval", "val"), "lengths.npz")
    if os.path.exists(lp_t) and os.path.exists(lp_v):
        from .texts import length_heuristic
        zt, zv = np.load(lp_t), np.load(lp_v)
        val_acc = {r: float(np.nanmean(length_heuristic(zv["gold"], zv["neg"], r))) for r in ("longest", "shortest")}
        rule = max(val_acc, key=val_acc.get)
        res["length_heuristic"] = {"val": val_acc, "rule": rule,
                                   "test": float(np.nanmean(length_heuristic(zt["gold"], zt["neg"], rule)))}
    lo, hi = GATES["G3_bands"]
    b = res["blind"]["tgem"]
    res["G3"] = "despreciable" if b < lo else ("moderado" if b < hi else "ALTO: cambiar métrica primaria")
    res["G3_pass"] = b < hi
    save_json(res, res_p)
    log(f"[F0.6] ciego={res['blind']} coseno_crudo={res['raw_cosine']} longitud={res.get('length_heuristic')} "
        f"-> G3 {res['G3']}")
    return res


# --------------------------------------------------------------------------------------
REPRO_VARIANTS = {
    "infonce_pre": dict(arm="infonce", stages=["pre"]),
    "infonce_hn_hnonly": dict(arm="infonce_hn", loss_params={"hn_denominator": "hn_only"}),
    "infonce_hn_inbatch": dict(arm="infonce_hn", loss_params={"hn_denominator": "hn_plus_inbatch"}),
    "infonce_hn_start": dict(arm="infonce_hn", hn_from_start=True, loss_params={"hn_denominator": "hn_only"}),
}


def f0_7_reproduction(study, bundle=None, seeds=(0, 1), variants=None, log=print) -> dict:
    """G2: reproducir la receta de CLM (pre / pre→mid / HN desde el inicio)."""
    out = _out(study, "F0.7_reproduction")
    bundle = bundle or load_bundle(study)
    res = load_json(os.path.join(out, "result.json"), {}) or {}
    res.setdefault("runs", {})
    for name, kw in (variants or REPRO_VARIANTS).items():
        for s in seeds:
            key = f"{name}/seed_{s}"
            if key in res["runs"]:
                continue
            kw2 = dict(kw)
            cfg = base_cfg(study, kw2.pop("arm"), seed=s, **kw2)
            r = run_one(study, bundle, cfg, "F0.7", f"{name}/seed_{s}")
            hist = []
            for stg in r.get("stages", {}):
                sj = load_json(study.paths.d("runs", "F0.7", name, f"seed_{s}", f"stage_{stg}.json"), {}) or {}
                hist += [h.get("val_top1") for h in sj.get("history", []) if not h.get("init")]
            res["runs"][key] = {"tgem_top1": r.get("test", {}).get("tgem", {}).get("top1"),
                                "val_peak": max([h for h in hist if h is not None], default=None),
                                "val_final": hist[-1] if hist else None}
            save_json(res, os.path.join(out, "result.json"))
    # cabezales públicos de CLM en tgem (referencia CONTAMINADA: vieron estos pares)
    res.setdefault("clm_public_contaminated", {})
    ck1 = load_json(study.paths.d("f0", "F0.1_checkpoints", "result.json"), {}) or {}
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    for k, v in (ck1.get("heads") or {}).items():
        if k in res["clm_public_contaminated"] or "deepswe" in k or "path" not in v:
            continue
        try:
            h = heads_from_clm_checkpoint(load_torch(v["path"]), dev)
            C, _ = cos_matrix(h, bundle.test, dev)
            res["clm_public_contaminated"][k] = rank_metrics(C)[0]["top1"]
        except Exception as e:
            res["clm_public_contaminated"][k] = f"error: {e}"
    # G2
    def mean_of(prefix, field):
        xs = [v[field] for kk, v in res["runs"].items() if kk.startswith(prefix + "/") and v.get(field) is not None]
        return float(np.mean(xs)) if xs else None
    pre, mid_a, mid_b = mean_of("infonce_pre", "tgem_top1"), mean_of("infonce_hn_hnonly", "tgem_top1"), \
        mean_of("infonce_hn_inbatch", "tgem_top1")
    start_peak = mean_of("infonce_hn_start", "val_peak")
    mid = max(x for x in (mid_a, mid_b) if x is not None) if (mid_a or mid_b) else None
    tol = GATES["G2_tol_pp"] / 100
    ref = GATES["G2_ref"]
    full_scale = study.data.profile in ("full",)
    res["G2"] = {"pre": pre, "mid_hnonly": mid_a, "mid_inbatch": mid_b, "start_peak_val": start_peak,
                 "ordering_ok": None if None in (pre, mid, start_peak) else bool(mid > start_peak > pre)}
    if full_scale and None not in (pre, mid):
        res["G2"]["abs_ok"] = bool(abs(pre - ref["pre"]) <= tol and abs(mid - ref["mid"]) <= tol)
    else:
        res["G2"]["abs_ok"] = None
        res["G2"]["nota"] = "perfil reducido: G2 sólo cualitativo (orden mid > pico de HN desde el inicio > pre)"
    res["G2_pass"] = bool(res["G2"]["ordering_ok"]) if res["G2"]["abs_ok"] is None else bool(
        res["G2"]["ordering_ok"] and res["G2"]["abs_ok"])
    save_json(res, os.path.join(out, "result.json"))
    log(f"[F0.7] G2={res['G2']}")
    return res


COLLAPSE_ARMS = ["simsiam_x", "byol_x", "barlow_x", "vicreg_x", "mse_sigreg", "align_unif", "dino_x", "swav_x"]


def f0_8_collapse(study, bundle=None, arms=None, aug_levels=(0.0, 0.5), row_fraction: float = 0.2,
                  max_steps: int | None = 300, log=print) -> dict:
    """G4: distinguir colapso por bug de colapso del método (corridas cortas, con/sin aumentación)."""
    out = _out(study, "F0.8_collapse")
    res_p = os.path.join(out, "result.json")
    res = load_json(res_p, {}) or {}
    bundle = bundle or load_bundle(study)
    dev = "cuda" if torch.cuda.is_available() else "cpu"
    chance = 1 / (1 + study.data.k_neg)
    for arm in (arms or COLLAPSE_ARMS):
        for aug in aug_levels:
            key = f"{arm}|aug={aug}"
            if key in res:
                continue
            cfg = base_cfg(study, arm, stages=["pre"], max_steps_pre=max_steps, aug_noise_std=aug, save_final=True)
            name = f"{arm}_aug{aug}".replace(".", "p")
            r = run_one(study, bundle, cfg, "F0.8", name, evaluate=False, row_fraction=row_fraction)
            if r.get("status") != "ok":
                res[key] = {"status": r.get("status"), "error": r.get("error"), "collapsed": True}
                save_json(res, res_p)
                continue
            from .evaluate import cos_with_pool
            from .train import Trainer
            rdir = study.paths.d("runs", "F0.8", name)
            tr = Trainer(cfg, bundle, rdir, row_fraction=row_fraction)
            # el colapso se diagnostica en el estado FINAL (no en el mejor checkpoint de validación)
            st = torch.load(os.path.join(rdir, "final_pre.pt"), map_location=tr.device, weights_only=False)
            tr.heads.load_state_dict(st["heads"])
            g = geometry(tr.heads, bundle.val, dev, n=min(2000, bundle.val.n))
            v = quick_val(tr.heads, bundle.val, dev)
            nv = bundle.val.n
            I = rng(3, nv).integers(0, nv - 1, size=(nv, 10))
            I = I + (I >= np.arange(nv)[:, None])          # nunca el propio ítem
            Crand = cos_with_pool(tr.heads, bundle.val, I, dev)
            rand_top1 = float(rank_metrics(Crand)[1].mean())
            rk_min = GATES["G4_rankme_frac"] * study.train.proj
            collapsed = g["rankme_zs"] < rk_min or rand_top1 <= chance + GATES["G4_rand_margin"]
            sj = load_json(os.path.join(rdir, "stage_pre.json"), {}) or {}
            res[key] = {"status": "ok", "steps": sj.get("steps"), "rankme_zs": g["rankme_zs"],
                        "rankme_za": g["rankme_za"], "rankme_min": rk_min, "val_top1_final": v["val_top1"],
                        "val_top1_best": sj.get("best"), "val_top1_init": sj.get("init_val"),
                        "rand_top1_final": rand_top1, "collapsed": bool(collapsed)}
            save_json(res, res_p)
            log(f"[F0.8] {key}: {res[key]}")
            for fn in os.listdir(study.paths.d("runs", "F0.8", name)):
                if fn.endswith(".pt"):
                    os.remove(study.paths.d("runs", "F0.8", name, fn))
    return res


def f0_9_trex(study, log=print) -> dict:
    out = _out(study, "F0.9_trex")
    res_p = os.path.join(out, "result.json")
    if (r := _cached(res_p)) is not None:
        return r
    from huggingface_hub import hf_hub_download
    from .trex import run_trex, setup_clm_repo
    repo = setup_clm_repo()
    head = hf_hub_download(CLM_HEAD_REPO, "CLM_v0.1-8B.pt", local_dir=study.paths.c("hf", slug(CLM_HEAD_REPO)))
    r = run_trex(head, out, repo=repo, log=log)
    ag = (r.get("shield") or {}).get("mean_agreement_with_planner")
    ok = ag is not None and abs(ag - GATES["G5_ref_agreement"]) <= GATES["G5_tol"] and \
        (r["shield"].get("survived") == 5) and (r["shield"].get("host_stall_seconds", 0) < 1.0)
    res = {**r, "G5_pass": bool(ok), "referencia_repo": {"shield_agreement": GATES["G5_ref_agreement"]}}
    save_json(res, res_p)
    return res


def f0_10_deepswe(study, log=print) -> dict:
    from .deepswe import f0_deepswe
    from .trex import setup_clm_repo
    return f0_deepswe(study.paths, repo=setup_clm_repo(), log=log)


def f0_report(study, log=print) -> dict:
    """Tabla de compuertas G1–G6 a partir de los resultados guardados."""
    p = study.paths.d("f0")
    g = {}
    r3 = load_json(os.path.join(p, "F0.3_embeddings", "result.json"))
    g["G1 pipeline de embeddings"] = None if r3 is None else r3.get("G1_pass")
    r7 = load_json(os.path.join(p, "F0.7_reproduction", "result.json"))
    g["G2 reproducción InfoNCE"] = None if r7 is None else r7.get("G2_pass")
    r6 = load_json(os.path.join(p, "F0.6_shortcuts", "result.json"))
    g["G3 atajos (modelo ciego)"] = None if r6 is None else r6.get("G3_pass")
    r8 = load_json(os.path.join(p, "F0.8_collapse", "result.json"))
    g["G4 colapso explicado"] = None if not r8 else not all(v.get("collapsed") for v in r8.values())
    r9 = load_json(os.path.join(p, "F0.9_trex", "result.json"))
    g["G5 arnés T-Rex"] = None if r9 is None else r9.get("G5_pass")
    r10 = load_json(os.path.join(p, "F0.10_deepswe", "result.json"))
    g["G6 identidad DeepSWE"] = None if r10 is None else r10.get("G6_pass")
    r4 = load_json(os.path.join(p, "F0.4_splits", "result.json"))
    extra = {"splits_sin_fuga": None if r4 is None else (r4.get("leaked_rows") == 0 and r4.get("all_aligned"))}
    lines = ["# F0 — reporte de compuertas", "", "| Compuerta | Estado |", "|---|---|"]
    for k, v in {**g, **extra}.items():
        lines.append(f"| {k} | {'PENDIENTE' if v is None else ('PASA' if v else 'NO PASA')} |")
    lines += ["", "G4 'PASA' = al menos una configuración no colapsa; revisar el detalle por brazo en F0.8.",
              "Una compuerta que no pasa se registra y se diagnostica; no se cambia el umbral después de ver el resultado."]
    md = "\n".join(lines)
    with open(os.path.join(p, "F0_REPORT.md"), "w") as f:
        f.write(md)
    save_json({"gates": g, **extra}, os.path.join(p, "F0_REPORT.json"))
    log(md)
    return {"gates": g, **extra}
