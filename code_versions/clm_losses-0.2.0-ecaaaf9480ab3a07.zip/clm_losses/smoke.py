"""Prueba de humo con datos sintéticos (mismo layout de archivos que los datos reales).

Recorre, en pequeño, TODO el flujo del notebook: F0.4–F0.6 y F0.8, una corrida por brazo con
HPO (F1), el análisis todos-contra-todos, un experimento F2 (B3: HN desde el inicio), el
PROTOCOL FREEZE y un F3 confirmatorio reducido sobre el test sellado.

Los datos sintéticos traen un "artefacto del generador" en los HN (una dirección fija que un
modelo ciego puede aprender) y un segundo generador sin artefacto (T-gen2). Así el smoke también
comprueba que el pipeline DETECTA atajos: un brazo con HN debería subir en T-gem y caer en T-gen2.
No dice nada sobre las pérdidas con datos reales."""
from __future__ import annotations

import os
import time

import numpy as np

from .data import synthetic_gen2_negatives
from .utils import atomic_np_save, save_json

SMOKE_LOSS_PARAMS = {"exp_dim": 256, "K": 256, "pred_hidden": 64, "n_slices": 64, "freeze_steps": 5}


def _synthetic_gen2(study, evalset, out_dir: str) -> None:
    if os.path.exists(os.path.join(out_dir, "gen2_negs.npy")):
        return
    os.makedirs(out_dir, exist_ok=True)
    negs = synthetic_gen2_negatives(study.paths.c("synthetic", "pre"), study.data.shard, evalset)
    atomic_np_save(np.arange(evalset.n), os.path.join(out_dir, "gen2_items.npy"))
    atomic_np_save(negs, os.path.join(out_dir, "gen2_negs.npy"))


def run_smoke(drive_base: str, cache_root: str = "/content/cache", arms=None, n_trials: int = 2,
              seeds=(0, 1), mount: bool = True, full_flow: bool = True, log=print) -> dict:
    from . import f0
    from .losses import arm_names
    from .pipeline import (compare_variants, export_summary_md, load_bundle, plot_val_curves, progress,
                           protocol_freeze, run_all_vs_all, run_arm, run_confirm_arm, run_variant, setup)
    t0 = time.time()
    study = setup("smoke", drive_base=drive_base, cache_root=cache_root, mount=mount,
                  train_overrides={"loss_params": SMOKE_LOSS_PARAMS})
    out = {"profile": "smoke", "drive_root": study.paths.drive_root}
    out["F0.4"] = f0.f0_4_splits(study, log=log)
    out["F0.5"] = f0.f0_5_eval_sets(study, lengths=False, qc=False, log=log)
    bundle = load_bundle(study, localize=False)
    _synthetic_gen2(study, bundle.test, bundle.gen2_dir)
    out["F0.6"] = f0.f0_6_shortcuts(study, bundle, log=log)
    out["F0.8"] = f0.f0_8_collapse(study, bundle, arms=["simsiam_x", "vicreg_x"], max_steps=40, log=log)
    # F1: un brazo = HPO + semillas
    arms = list(arms or arm_names())
    for arm in arms:
        run_arm(study, bundle, arm, n_trials=n_trials, seeds=list(seeds))
    out["progress"] = progress(study).to_dict("records")
    rep = run_all_vs_all(study, bundle, B=300)
    out["all_vs_all"] = {k: v for k, v in rep.items() if k in ("arms", "friedman", "C1")}
    out["resumen_F1"] = export_summary_md(study, "F1")
    if full_flow and {"infonce_hn", "infonce_sigreg", "infonce_lse"} <= set(arms):
        # F2 / B3: HN desde el inicio, con y sin regularizador (1 semilla)
        b3 = {"InfoNCE+HN": ("F2_B3", "infonce_hn_start"), "InfoNCE+SIGReg+HN": ("F2_B3", "infonce_sigreg_hn_start"),
              "InfoNCE+LSE+HN": ("F2_B3", "infonce_lse_hn_start")}
        run_variant(study, bundle, "infonce_hn", "F2_B3", "infonce_hn_start", seeds=[0], hn_from_start=True)
        run_variant(study, bundle, "infonce_sigreg", "F2_B3", "infonce_sigreg_hn_start", seeds=[0],
                    hn_from_start=True, hn_mode="native")
        run_variant(study, bundle, "infonce_lse", "F2_B3", "infonce_lse_hn_start", seeds=[0],
                    hn_from_start=True, hn_mode="native")
        out["F2_B3"] = {k: v for k, v in compare_variants(study, bundle, b3, "B3", B=300).items()
                        if k in ("arms", "metrics")}
        out["F2_B3_curvas"] = plot_val_curves(study, b3, study.paths.d("results", "F2", "B3", "curvas_val.png"))
    if full_flow and len(arms) == len(arm_names()):
        # PROTOCOL FREEZE + F3 reducido (3 brazos) sobre el test SELLADO
        frz = protocol_freeze(study, note="smoke: sólo prueba de código")
        bundle_c = load_bundle(study, localize=False, test_split="confirm")
        _synthetic_gen2(study, bundle_c.test, bundle_c.gen2_dir)
        for arm in sorted({"infonce", frz["C1_best_noncontrastive"], "siglip"}):
            run_confirm_arm(study, bundle_c, arm, seeds=list(seeds))
        rep3 = run_all_vs_all(study, bundle_c, phase="F3", B=300)
        out["F3"] = {k: v for k, v in rep3.items() if k in ("arms", "C1")}
        out["resumen_F3"] = export_summary_md(study, "F3")
    out["minutes"] = round((time.time() - t0) / 60, 1)
    save_json(out, study.paths.d("results", "SMOKE_SUMMARY.json"))
    log(f"[smoke] OK en {out['minutes']} min -> {study.paths.d('results')}")
    return out
