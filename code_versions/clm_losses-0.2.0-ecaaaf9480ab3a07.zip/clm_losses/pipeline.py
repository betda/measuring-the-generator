"""Funciones de alto nivel que llama cada celda del notebook."""
from __future__ import annotations

import dataclasses
import os
import shutil
import sys
from dataclasses import dataclass

import numpy as np

from .config import (HN_REPO, PRETRAIN_REPO, EvalConfig, HPOConfig, Paths, StudyConfig, TrainConfig,
                     data_config)
from .data import (EvalSet, HFDownloader, Split, Store, make_synthetic_store, slug, train_masks)
from .hpo import apply_overrides, run_hpo
from .losses import ARMS, NONCONTRASTIVE_POOL, arm_names
from .train import run_training
from .utils import (RunLogger, disk_free_gb, env_snapshot, gpu_info, load_json, makedirs, now_iso,
                    pip_freeze, ram_gb, read_done, save_json)


def in_colab() -> bool:
    return "google.colab" in sys.modules


def _config_diff(a: dict, b: dict, prefix: str = "") -> list:
    out = []
    for k in sorted(set(a) | set(b)):
        if k == "paths":
            continue
        va, vb = a.get(k), b.get(k)
        if isinstance(va, dict) and isinstance(vb, dict):
            out += _config_diff(va, vb, f"{prefix}{k}.")
        elif va != vb:
            out.append(f"{prefix}{k}: {va!r} -> {vb!r}")
    return out


def setup(profile: str = "colab", drive_base: str = "/content/drive/MyDrive/CLM_losses",
          cache_root: str = "/content/cache", mount: bool = True, train_overrides: dict | None = None,
          hpo_overrides: dict | None = None, study_overrides: dict | None = None,
          allow_config_change: bool = False, **data_overrides) -> StudyConfig:
    """Monta Drive, crea carpetas y carga/guarda la configuración del estudio.
    Cada perfil vive en su propia carpeta: <drive_base>/<profile>.

    La configuración queda congelada en <drive>/config/study.json la primera vez. En sesiones
    posteriores se carga la guardada y los overrides se aplican ENCIMA de ella: si piden algo distinto,
    se detiene (para no mezclar corridas con configuraciones distintas) salvo allow_config_change=True,
    que archiva la anterior en config/history/."""
    import copy
    if mount and in_colab():
        from google.colab import drive
        if not os.path.isdir("/content/drive/MyDrive"):
            drive.mount("/content/drive")
    paths = Paths(drive_root=os.path.join(drive_base, profile), cache_root=cache_root).make()
    cfg_path = paths.d("config", "study.json")
    saved = None
    if os.path.exists(cfg_path):
        saved = StudyConfig.load(cfg_path)
        saved.paths = paths
        study = copy.deepcopy(saved)
    else:
        study = StudyConfig(paths=paths, data=data_config(profile))
        if profile == "smoke":
            study.train = TrainConfig(width=128, depth=3, proj=64, batch_pre=256, batch_mid=64, eval_every=25,
                                      patience=4, pre_epochs=2.0, mid_epochs=1.0, ckpt_every_steps=50)
            study.hpo = HPOConfig(n_trials=3, budget_frac=0.5)
            study.eval = EvalConfig(n_geo=500, eval_batch=512)
            study.f1_seeds = [0, 1]
    if data_overrides:
        study.data = dataclasses.replace(study.data, **data_overrides)
    if train_overrides:
        study.train = dataclasses.replace(study.train, **train_overrides)
    if hpo_overrides:
        study.hpo = dataclasses.replace(study.hpo, **hpo_overrides)
    for k, v in (study_overrides or {}).items():
        if k not in ("f1_seeds", "f3_seeds", "rope_pp"):
            raise KeyError(f"study_overrides admite f1_seeds, f3_seeds y rope_pp; no {k!r}")
        setattr(study, k, v)
    if saved is None:
        study.save(cfg_path)
    else:
        diff = _config_diff(saved.to_dict(), study.to_dict())
        if diff and not allow_config_change:
            raise RuntimeError(
                "La configuración pedida difiere de la guardada en Drive (" + cfg_path + "):\n  "
                + "\n  ".join(diff)
                + "\nPara no mezclar corridas incompatibles me detengo. Opciones: (a) deja los parámetros como "
                  "estaban; (b) usa otro DRIVE_BASE o perfil; (c) allow_config_change=True si sabes lo que haces "
                  "(las corridas ya hechas NO se rehacen solas).")
        if diff:
            save_json(saved.to_dict(), paths.d("config", "history", f"study_{now_iso().replace(':', '')}.json"))
            study.save(cfg_path)
    snap = env_snapshot()
    snap.update(disk_free_cache_gb=round(disk_free_gb(cache_root), 1), profile=profile)
    save_json(snap, paths.d("logs", f"env_{now_iso().replace(':', '')}.json"))
    fz = paths.d("logs", "pip_freeze.txt")
    if not os.path.exists(fz):
        with open(fz, "w") as f:
            f.write(pip_freeze())
    return study


def resources(study: StudyConfig) -> dict:
    """Chequeo de recursos antes de descargar."""
    need = study.data.disk_gb() if not study.data.synthetic else 0.1
    free = disk_free_gb(study.paths.cache_root)
    r = {"gpu": gpu_info(), "ram_gb": round(ram_gb(), 1), "disco_libre_gb": round(free, 1),
         "disco_necesario_gb": round(need, 1), "alcanza": free > need * 1.05}
    if not r["alcanza"]:
        r["sugerencia"] = "usa un perfil menor (mini) o reduce pre_chunks; ver config.PROFILES"
    return r


# --------------------------------------------------------------------------------------
def make_store(study: StudyConfig) -> Store:
    p, d = study.paths, study.data
    if d.synthetic:
        pre_root, hn_root = p.c("synthetic", "pre"), p.c("synthetic", "hn")
        info = make_synthetic_store(pre_root, hn_root, d.shard, n_chunks=max(d.pre_chunks) + 1,
                                    hn_chunks=d.hn_chunks, k=d.k_neg, **d.syn)
        fp = p.d("data", "SYNTHETIC_fingerprint.json")
        old = load_json(fp) if os.path.exists(fp) else None
        if old is not None and old != info:
            raise RuntimeError(f"Los datos sintéticos cambiaron respecto de los derivados guardados en {p.d('data')}. "
                               f"Borra la carpeta {p.drive_root} (sólo es el smoke) y vuelve a correr.")
        if old is None:
            save_json(info, fp)
        return Store(pre_root, hn_root, d.shard)
    return Store(p.c("hf", slug(PRETRAIN_REPO)), p.c("hf", slug(HN_REPO)), d.shard, downloader=HFDownloader(),
                 pre_repo=PRETRAIN_REPO, hn_repo=HN_REPO)


@dataclass
class DataBundle:
    study: StudyConfig
    store: Store
    split: Split
    masks_pre: dict
    masks_mid: dict
    val: EvalSet
    test: EvalSet
    hidden: int
    test_split: str = "test"      # "test" (exploratorio) o "confirm" (sellado; sólo tras el freeze)

    @property
    def dcfg(self):
        return self.study.data

    @property
    def pools_dir(self) -> str:
        return self.study.paths.d("data", "eval", self.test_split)

    @property
    def gen2_dir(self) -> str:
        return self.study.paths.d("data", "eval", "gen2" if self.test_split == "test" else f"gen2_{self.test_split}")


def _localize(src: str, dst: str) -> str:
    """Copia un set de evaluación de Drive a disco local (lecturas más rápidas)."""
    if os.path.exists(os.path.join(dst, "manifest.json")):
        return dst
    tmp = dst + ".tmp"
    if os.path.exists(tmp):
        shutil.rmtree(tmp)
    shutil.copytree(src, tmp)
    os.replace(tmp, dst)
    return dst


def freeze_path(study: StudyConfig) -> str:
    return study.paths.d("config", "PROTOCOL_FREEZE.json")


def load_bundle(study: StudyConfig, localize: bool = True, test_split: str = "test") -> DataBundle:
    """Carga splits, máscaras y sets de evaluación. test_split='confirm' sólo después del freeze."""
    p, d = study.paths, study.data
    if test_split not in ("test", "confirm"):
        raise ValueError("test_split debe ser 'test' o 'confirm'")
    if test_split == "confirm" and not os.path.exists(freeze_path(study)):
        raise PermissionError("El test confirmatorio está SELLADO: primero ejecuta la celda de PROTOCOL FREEZE "
                              "(protocol_freeze). Después del freeze no se optimiza nada con este test.")
    store = make_store(study)
    sdir = p.d("data", "splits")
    split = Split.load(sdir)
    masks_pre = train_masks(store, split, d.pre_chunks, sdir, "pre")
    masks_mid = train_masks(store, split, d.hn_chunks, sdir, "mid")
    vdir, tdir = p.d("data", "eval", "val"), p.d("data", "eval", test_split)
    if localize and not d.synthetic:
        vdir = _localize(vdir, p.c("eval_local", "val"))
        tdir_local = _localize(tdir, p.c("eval_local", test_split))
    else:
        tdir_local = tdir
    val, test = EvalSet(vdir), EvalSet(tdir_local)
    hidden = int(val.q_all().shape[1])
    return DataBundle(study, store, split, masks_pre, masks_mid, val, test, hidden, test_split)


def extra_sets(bundle: DataBundle) -> dict:
    from .texts import load_gen2
    g = load_gen2(bundle.gen2_dir)
    return {"tgen2": g} if g is not None else {}


# --------------------------------------------------------------------------------------
def base_cfg(study: StudyConfig, arm: str, **kw) -> TrainConfig:
    c = dataclasses.replace(study.train, arm=arm, loss_params=dict(study.train.loss_params))
    for k, v in kw.items():
        setattr(c, k, v)
    return c


def run_one(study, bundle, cfg: TrainConfig, phase: str, name: str, evaluate: bool = True,
            row_fraction: float = 1.0, cleanup: bool = False) -> dict:
    rd = study.paths.d("runs", phase, name)
    return run_training(cfg, bundle, rd, ecfg=study.eval, evaluate_test=evaluate, row_fraction=row_fraction,
                        pools_dir=bundle.pools_dir if evaluate else None,
                        extra_sets=extra_sets(bundle) if evaluate else None, cleanup_heavy=cleanup)


def run_arm(study, bundle, arm: str, phase: str = "F1", seeds=None, n_trials: int | None = None,
            budget_frac: float | None = None, **cfg_kw) -> dict:
    """Una celda = un brazo: búsqueda de HP (reanudable) + semillas finales + evaluación."""
    if arm not in ARMS:
        raise KeyError(f"brazo desconocido {arm!r}; opciones: {arm_names()}")
    arm_dir = study.paths.d("runs", phase, arm)
    makedirs(arm_dir)
    log = RunLogger(arm_dir, "arm_log.jsonl", prefix=f"[{phase}:{arm}] ")
    base = base_cfg(study, arm, **cfg_kw)
    nt = n_trials if n_trials is not None else study.hpo.n_trials
    bf = budget_frac if budget_frac is not None else study.hpo.budget_frac

    def trial_fn(cfg, rd, frac):
        return run_training(cfg, bundle, rd, ecfg=study.eval, evaluate_test=False, row_fraction=frac,
                            cleanup_heavy=True, export_clm=False)
    hpo = run_hpo(arm, base, bundle, arm_dir, nt, bf, study.hpo.seed, trial_fn, log=log.log)
    best = hpo["best"]["overrides"]
    log.log("mejor configuración", overrides=best, val=hpo["best"]["val_best"])
    results = []
    for s in (seeds if seeds is not None else study.f1_seeds):
        cfg = apply_overrides(base, best)
        cfg.arm, cfg.seed = arm, int(s)
        rd = os.path.join(arm_dir, f"seed_{s}")
        res = run_training(cfg, bundle, rd, ecfg=study.eval, evaluate_test=True, pools_dir=bundle.pools_dir,
                           extra_sets=extra_sets(bundle))
        results.append(res)
        t = res.get("test", {}).get("tgem", {})
        log.log(f"semilla {s}", status=res.get("status"), top1=t.get("top1"), abst=t.get("abst_auroc_maxcos"))
    summary = {"arm": arm, "phase": phase, "best_overrides": best, "hpo_best_val": hpo["best"]["val_best"],
               "evp_curve": hpo["evp_curve"], "seeds": results}
    save_json(summary, os.path.join(arm_dir, "ARM_SUMMARY.json"))
    return summary


def best_overrides(study, arm: str, phase: str = "F1") -> dict:
    """Hiperparámetros elegidos en validación para un brazo (hpo_summary.json de la fase)."""
    s = load_json(study.paths.d("runs", phase, arm, "hpo_summary.json"))
    if s is None:
        raise FileNotFoundError(f"{arm}: falta runs/{phase}/{arm}/hpo_summary.json (corre primero su celda de {phase})")
    return dict(s["best"]["overrides"])


def run_variant(study, bundle, arm: str, phase: str, name: str, seeds=None, hp_from: str | None = "F1",
                evaluate: bool = True, **cfg_kw) -> list:
    """Una variante (F2: regímenes de HN, currículo, batch, ...) con los HP de `hp_from` (sin re-tuning).
    Cada semilla queda en runs/<phase>/<name>/seed_<s> y se reanuda sola."""
    base = base_cfg(study, arm)
    if hp_from:
        base = apply_overrides(base, best_overrides(study, arm, hp_from))
    lp = cfg_kw.pop("loss_params", None)
    for k, v in cfg_kw.items():
        if not hasattr(base, k):
            raise AttributeError(f"TrainConfig no tiene {k!r}")
        setattr(base, k, v)
    if lp:
        base.loss_params = {**base.loss_params, **lp}
    out = []
    for s in (seeds if seeds is not None else study.f1_seeds):
        cfg = dataclasses.replace(base, arm=arm, seed=int(s), loss_params=dict(base.loss_params))
        rd = study.paths.d("runs", phase, name, f"seed_{s}")
        out.append(run_training(cfg, bundle, rd, ecfg=study.eval, evaluate_test=evaluate,
                                pools_dir=bundle.pools_dir if evaluate else None,
                                extra_sets=extra_sets(bundle) if evaluate else None))
    return out


def protocol_freeze(study, phase: str = "F1", note: str = "", force: bool = False) -> dict:
    """PROTOCOL FREEZE (§7.8): congela HP por brazo, brazo no contrastivo de C1, métricas y estadística.
    Después de esto sólo se corre F3 (sin tuning) y recién entonces se abre el test confirmatorio."""
    from .utils import code_hash
    fp = freeze_path(study)
    if os.path.exists(fp) and not force:
        return load_json(fp)
    arms = {}
    missing = []
    for arm in arm_names():
        try:
            arms[arm] = {"overrides": best_overrides(study, arm, phase),
                         "val_best": (load_json(study.paths.d("runs", phase, arm, "hpo_summary.json")) or {})
                         .get("best", {}).get("val_best")}
        except FileNotFoundError:
            missing.append(arm)
    if missing:
        raise RuntimeError(f"No se puede congelar: faltan brazos de {phase}: {missing}")
    pool = [a for a in NONCONTRASTIVE_POOL if a in arms]
    best_nc = max(pool, key=lambda a: arms[a]["val_best"] if arms[a]["val_best"] is not None else -1)
    frz = {"created": now_iso(), "code_hash": code_hash(), "source_phase": phase, "note": note,
           "study_config": study.to_dict(), "arms": arms,
           "C1_best_noncontrastive": best_nc,
           "C1_rule": "mejor no contrastiva elegida por val_best (validación) en " + phase,
           "primary_metric": "top-1 en T-gem (test confirmatorio)",
           "secondary_metrics": ["top-1 en T-rand, T-mine, T-gen2", "AUROC de abstención (T-abst)",
                                 "ECE listwise con temperature scaling", "MRR"],
           "seeds": list(study.f3_seeds), "rope_pp": study.rope_pp,
           "statistics": "bootstrap jerárquico pareado (documentos; semillas dentro de brazo), Holm sobre los "
                         "105 pares por métrica, TOST ±ROPE, Friedman + Nemenyi; C1 como contraste confirmatorio",
           "success_criterion_C1": f"|Δ| ≥ {study.rope_pp} pp con p_Holm < 0.05 (superioridad/inferioridad) "
                                   f"o equivalencia por TOST dentro de ±{study.rope_pp} pp"}
    save_json(frz, fp)
    lines = [f"# PROTOCOL FREEZE — {frz['created']}", "", f"code_hash: `{frz['code_hash']}`", "",
             f"C1: **{best_nc}** vs **infonce** (elegido en validación de {phase})", "",
             "| brazo | val_best | HP congelados |", "|---|---|---|"]
    for a, v in arms.items():
        lines.append(f"| {a} | {v['val_best']} | `{v['overrides']}` |")
    with open(study.paths.d("config", "PROTOCOL_FREEZE.md"), "w") as f:
        f.write("\n".join(lines))
    return frz


def run_confirm_arm(study, bundle_c, arm: str, seeds=None) -> dict:
    """F3 (confirmatorio): HP congelados, sin tuning, evaluación en el test sellado."""
    if bundle_c.test_split != "confirm":
        raise ValueError("usa bundle_c = load_bundle(study, test_split='confirm')")
    from .utils import code_hash
    frz = load_json(freeze_path(study))
    ov = frz["arms"][arm]["overrides"]
    arm_dir = study.paths.d("runs", "F3", arm)
    makedirs(arm_dir)
    h = code_hash()
    if h != frz.get("code_hash"):
        print(f"[F3] ADVERTENCIA: el código actual ({h}) no es el congelado ({frz.get('code_hash')}). "
              "Si el cambio toca entrenamiento o evaluación, F3 deja de ser confirmatorio; regístralo.")
    results = []
    for s in (seeds if seeds is not None else frz["seeds"]):
        cfg = apply_overrides(base_cfg(study, arm), ov)
        cfg.arm, cfg.seed = arm, int(s)
        res = run_training(cfg, bundle_c, os.path.join(arm_dir, f"seed_{s}"), ecfg=study.eval, evaluate_test=True,
                           pools_dir=bundle_c.pools_dir, extra_sets=extra_sets(bundle_c),
                           export_clm=(int(s) == int(frz["seeds"][0])))   # T-Rex usa la primera semilla
        results.append(res)
    summary = {"arm": arm, "phase": "F3", "frozen_overrides": ov, "code_hash": h,
               "code_hash_frozen": frz.get("code_hash"), "seeds": results}
    save_json(summary, os.path.join(arm_dir, "ARM_SUMMARY.json"))
    return summary


def export_head_from_run(study, run_dir: str) -> str:
    """Exporta clm_head.pt (formato clm-serve) desde best_<última etapa>.pt de una corrida terminada."""
    from .config import train_config_from_dict
    from .train import Trainer, export_clm_head
    cfg = train_config_from_dict(load_json(os.path.join(run_dir, "config.json"))["train"])

    class _B:   # el Trainer sólo necesita la dimensión de entrada para construir los cabezales
        hidden = int(load_json(os.path.join(run_dir, "eval", "metrics.json"), {}).get("hidden", 4096) or 4096)
        dcfg = study.data
    tr = Trainer(cfg, _B(), run_dir)
    if not tr.load_best(tr.stages[-1]):
        raise FileNotFoundError(f"{run_dir}: falta best_{tr.stages[-1]}.pt")
    return export_clm_head(tr.heads, load_json(os.path.join(run_dir, "eval", "metrics.json")), run_dir)


def add_missing_evals(study, bundle, phase: str = "F1", arms=None, log=print) -> int:
    """Agrega a corridas YA terminadas los conjuntos de test creados después (p. ej. T-gen2).
    No re-entrena: carga el mejor checkpoint de la última etapa y evalúa sólo lo que falta."""
    from .config import train_config_from_dict
    from .evaluate import evaluate_run
    from .train import Trainer
    from .utils import mark_done
    ex = extra_sets(bundle)
    n = 0
    for arm in (arms or arm_names()):
        base = study.paths.d("runs", phase, arm)
        if not os.path.isdir(base):
            continue
        for d in sorted(os.listdir(base)):
            rd = os.path.join(base, d)
            done = read_done(rd)
            if not d.startswith("seed_") or not done or done.get("status") != "ok":
                continue
            need = [k for k in ("trand", "tmine", *ex) if k not in (done.get("test") or {})]
            if not need:
                continue
            cfg = train_config_from_dict(load_json(os.path.join(rd, "config.json"))["train"])
            tr = Trainer(cfg, bundle, rd)
            if not tr.load_best(tr.stages[-1]):
                log(f"[re-eval] {arm}/{d}: falta best_{tr.stages[-1]}.pt; se omite")
                continue
            metrics = evaluate_run(tr.heads, tr.loss, bundle.test, bundle.val, os.path.join(rd, "eval"), tr.device,
                                   study.eval, pools_dir=bundle.pools_dir, extra_sets=ex, log=tr.log.log)
            done["test"] = {k: {kk: vv for kk, vv in v.items() if isinstance(vv, (int, float))}
                            for k, v in metrics.items() if isinstance(v, dict)}
            mark_done(rd, done)
            n += 1
            log(f"[re-eval] {arm}/{d}: agregado {need}")
    return n


def progress(study, phase: str = "F1"):
    """Tabla de avance por brazo (para retomar después de un corte)."""
    import pandas as pd
    rows = []
    for arm in arm_names():
        ad = study.paths.d("runs", phase, arm)
        hpo = load_json(os.path.join(ad, "hpo_summary.json"), {}) or {}
        seeds = [d for d in (os.listdir(ad) if os.path.isdir(ad) else []) if d.startswith("seed_")]
        done = [d for d in seeds if (read_done(os.path.join(ad, d)) or {}).get("status") == "ok"]
        tgem = [(read_done(os.path.join(ad, d)) or {}).get("test", {}).get("tgem", {}).get("top1") for d in done]
        tgem = [x for x in tgem if x is not None]
        rows.append({"#": ARMS[arm]["num"], "brazo": arm, "familia": ARMS[arm]["family"],
                     "trials_hpo": len(hpo.get("trials", [])), "semillas_ok": len(done),
                     "top1_tgem_media": round(float(np.mean(tgem)), 4) if tgem else None})
    return pd.DataFrame(rows).sort_values("#")


def run_all_vs_all(study, bundle, phase: str = "F1", testsets=("tgem", "trand", "tmine", "tgen2"), B: int = 2000):
    from .stats import all_vs_all, collect_failures, collect_runs, contrast, clusters_from_docs
    if (phase == "F3") != (bundle.test_split == "confirm"):
        raise ValueError("F3 se analiza con el bundle confirmatorio y F1/F2 con el exploratorio")
    runs = collect_runs(study.paths.runs, phase, arm_names())
    failed = collect_failures(study.paths.runs, phase, arm_names())
    out_dir = study.paths.d("results", phase, "all_vs_all")
    ex = extra_sets(bundle)
    gen2_items = ex["tgen2"][0] if "tgen2" in ex else None
    report = all_vs_all(runs, list(testsets), bundle.test.doc_ids, out_dir, rope_pp=study.rope_pp, B=B,
                        gen2_items=gen2_items, failed=failed)
    report["code_hashes"] = {a: sorted({(load_json(os.path.join(rd, "config.json"), {}) or {}).get("env", {})
                                        .get("code_hash") for _, rd in lst} - {None}) for a, lst in runs.items()}
    mixed = {a: h for a, h in report["code_hashes"].items() if len(h) > 1}
    if len({h for hs in report["code_hashes"].values() for h in hs}) > 1:
        print(f"[stats] ATENCIÓN: las corridas usan más de una versión del código: {report['code_hashes']}")
    report["code_mixed_within_arm"] = mixed
    # C1 (H1a): mejor no contrastiva (elegida en VALIDACIÓN) vs InfoNCE, en tgem.
    # En F3 el brazo es el congelado en PROTOCOL_FREEZE.json (no se vuelve a elegir).
    pool = [a for a in NONCONTRASTIVE_POOL if a in runs]
    if "infonce" in runs and pool:
        def val_of(a):
            s = load_json(study.paths.d("runs", "F1", a, "hpo_summary.json"), {}) or {}
            return (s.get("best") or {}).get("val_best", -1)
        best_nc = load_json(freeze_path(study))["C1_best_noncontrastive"] if phase == "F3" else max(pool, key=val_of)
        A = np.vstack([np.load(os.path.join(rd, "eval", "correct_tgem.npy")) for _, rd in runs[best_nc]])
        Bm = np.vstack([np.load(os.path.join(rd, "eval", "correct_tgem.npy")) for _, rd in runs["infonce"]])
        c1 = contrast(A.astype(np.float32), Bm.astype(np.float32), clusters_from_docs(bundle.test.doc_ids),
                      study.rope_pp / 100, B=4000)
        rope = study.rope_pp / 100
        if c1["significant"] and abs(c1["diff"]) >= rope:
            verdict = f"{best_nc} mejor" if c1["diff"] > 0 else "infonce mejor"
        elif c1["significant"]:
            verdict = "diferencia significativa pero < ROPE (sin relevancia práctica)"
        elif c1["tost_equivalent"]:
            verdict = f"equivalentes (TOST ±{study.rope_pp} pp)"
        else:
            verdict = "no concluyente"
        c1.update(A=best_nc, B="infonce", best_noncontrastive=best_nc, confirmatory=(phase == "F3"), verdict=verdict)
        report["C1"] = c1
        save_json(report, os.path.join(out_dir, "all_vs_all.json"))
    return report


# --------------------------------------------------------------------------------------
# Utilidades para mostrar resultados en el notebook
def summarize_arm(summary: dict):
    """Tabla compacta de un brazo: una fila por semilla."""
    import pandas as pd
    rows = []
    for r in summary.get("seeds", []):
        t = r.get("test", {})
        rows.append({"semilla": r.get("seed"), "estado": r.get("status"),
                     "val_best": r.get("val_best"),
                     "top1_tgem": t.get("tgem", {}).get("top1"), "top1_trand": t.get("trand", {}).get("top1"),
                     "top1_tmine": t.get("tmine", {}).get("top1"), "top1_tgen2": t.get("tgen2", {}).get("top1"),
                     "abst_auroc": t.get("tgem", {}).get("abst_auroc_maxcos"),
                     "ece_ts": t.get("tgem", {}).get("ts_ece"),
                     "pasos_mid": r.get("stages", {}).get("mid", {}).get("steps"),
                     "mejor_paso_mid": r.get("stages", {}).get("mid", {}).get("best_step")})
    return pd.DataFrame(rows)


def compare_variants(study, bundle, variants: dict, out_name: str, testsets=("tgem", "trand", "tmine", "tgen2"),
                     B: int = 2000) -> dict:
    """Todos contra todos entre variantes con nombre: {etiqueta: (fase, nombre_de_carpeta)}."""
    from .stats import all_vs_all
    runs = {}
    for label, (phase, name) in variants.items():
        lst = []
        base = study.paths.d("runs", phase, name)
        if os.path.isdir(base):
            for d in sorted(os.listdir(base)):
                rd = os.path.join(base, d)
                done = read_done(rd)
                if d.startswith("seed_") and done and done.get("status") == "ok":
                    lst.append((int(done["seed"]), rd))
        if lst:
            runs[label] = lst
    missing = [k for k in variants if k not in runs]
    if missing:
        print(f"[comparar] sin corridas terminadas: {missing}")
    if len(runs) < 2:
        return {"runs": list(runs), "nota": "se necesitan al menos 2 variantes terminadas"}
    ex = extra_sets(bundle)
    return all_vs_all(runs, list(testsets), bundle.test.doc_ids, study.paths.d("results", "F2", out_name),
                      rope_pp=study.rope_pp, B=B, gen2_items=ex["tgen2"][0] if "tgen2" in ex else None)


def plot_val_curves(study, variants: dict, out_png: str, metric: str = "val_top1"):
    """Curvas de validación por variante (B3: ¿sube y luego cae con HN desde el inicio?)."""
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7, 4))
    for label, (phase, name) in variants.items():
        base = study.paths.d("runs", phase, name)
        if not os.path.isdir(base):
            continue
        for d in sorted(os.listdir(base)):
            if not d.startswith("seed_"):
                continue
            off = 0
            for stg in ("pre", "mid"):
                sj = load_json(os.path.join(base, d, f"stage_{stg}.json"))
                if not sj:
                    continue
                h = [x for x in sj["history"] if metric in x]
                ax.plot([off + x["step"] for x in h], [x[metric] for x in h], alpha=0.7,
                        label=f"{label} ({d}, {stg})")
                off += sj.get("steps", 0)
    ax.set_xlabel("paso (acumulado entre etapas)")
    ax.set_ylabel(metric)
    ax.legend(fontsize=6)
    fig.tight_layout()
    makedirs(os.path.dirname(out_png))
    fig.savefig(out_png, dpi=150)
    plt.close(fig)
    return out_png


def trex_for_arms(study, arms=None, phase: str = "F3", seed: int = 0, modes=("shield", "noshield"), log=print):
    """T-Rex (D2: con y sin shield) con el cabezal exportado de cada brazo. Reanudable por brazo y modo."""
    from .trex import run_trex, setup_clm_repo, stop_all
    repo = setup_clm_repo()
    out = {}
    try:
        for arm in (arms or arm_names()):
            rd = study.paths.d("runs", phase, arm, f"seed_{seed}")
            ck = os.path.join(rd, "clm_head.pt")
            if not os.path.exists(ck) and os.path.exists(os.path.join(rd, "DONE.json")):
                ck = export_head_from_run(study, rd)
            if not os.path.exists(ck):
                log(f"[trex] {arm}: falta {ck}; se omite")
                continue
            out[arm] = run_trex(ck, study.paths.d("results", phase, "trex", arm), repo=repo, modes=modes, log=log)
    finally:
        stop_all()
    save_json(out, study.paths.d("results", phase, "trex", "TREX_SUMMARY.json"))
    return out


def export_summary_md(study, phase: str = "F1") -> str:
    """Resumen en Markdown (para EXPERIMENT_LOG / PROJECT_STATE del proyecto)."""
    rep = load_json(study.paths.d("results", phase, "all_vs_all", "all_vs_all.json"), {}) or {}
    lines = [f"# Resumen {phase} — perfil {study.data.profile} — {now_iso()}", ""]
    for name, m in (rep.get("metrics") or {}).items():
        if "summary" not in m:
            continue
        lines += [f"## {name}", "", "| brazo | media | IC95 | semillas |", "|---|---|---|---|"]
        for r in m["summary"]:
            lines.append(f"| {r['arm']} | {r['mean']:.4f} | [{r['ci95_lo']:.4f}, {r['ci95_hi']:.4f}] | {r['n_seeds']} |")
        lines += ["", f"Pares significativos (Holm): {m['n_significant']}/{m['n_pairs']}; "
                      f"equivalentes (TOST ±{rep.get('rope_pp')} pp): {m['n_equivalent']}", ""]
    if "C1" in rep:
        c = rep["C1"]
        lines += ["## C1 (H1a)", "", f"{c.get('best_noncontrastive')} − infonce: Δ = {c.get('diff', float('nan')):.4f} "
                  f"IC95 [{c.get('ci95_lo', float('nan')):.4f}, {c.get('ci95_hi', float('nan')):.4f}], "
                  f"p = {c.get('p', float('nan')):.3g}, veredicto = {c.get('verdict')}, "
                  f"confirmatorio = {c.get('confirmatory')}", ""]
    md = "\n".join(lines)
    p = study.paths.d("results", phase, f"RESUMEN_{phase}.md")
    with open(p, "w") as f:
        f.write(md)
    return p


# --------------------------------------------------------------------------------------
# Planificación: disco por perfil, tiempo / unidades de cómputo y control de tunability
QWEN3_8B_GB = 16.4        # pesos bf16 de Qwen3-8B (≈ 8.2e9 parámetros × 2 bytes) [INFERENCE]
TOKENS_GB = 10.5          # qa_pairs (2.9 GB) + neg_pairs (7.6 GB) de los tokens de Nemotron (HF, 2026-09-30)


def profile_disk_table(cache_root: str = "/content/cache", margin: float = 1.10):
    """¿Qué perfil cabe en el disco local de ESTA máquina? (no crea ningún estudio)."""
    import pandas as pd
    os.makedirs(cache_root, exist_ok=True)
    free = disk_free_gb(cache_root)
    rows = []
    for name in ("mini", "colab", "colab_large"):
        d = data_config(name)
        emb = d.disk_gb()
        rows.append({"perfil": name, "pares_pre_training": len(d.pre_chunks) * 100_000,
                     "pares_con_HN": len(d.hn_chunks) * 100_000, "GB_embeddings": round(emb, 1),
                     "GB_si_además_corre_Qwen3_y_tokens": round(emb + QWEN3_8B_GB + TOKENS_GB, 1),
                     "cabe_para_entrenar": free >= emb * margin,
                     "cabe_con_todo": free >= (emb + QWEN3_8B_GB + TOKENS_GB) * margin})
    df = pd.DataFrame(rows)
    df.attrs["disco_libre_gb"] = round(free, 1)
    return df


def _done_runs(base: str, pattern: str):
    import glob
    out = []
    for p in glob.glob(os.path.join(base, pattern, "DONE.json")):
        d = load_json(p) or {}
        if d.get("status") == "ok" and d.get("train_seconds") is not None:
            cfg = load_json(os.path.join(os.path.dirname(p), "config.json"), {}) or {}
            out.append({"arm": d.get("arm"), "secs": float(d["train_seconds"]) + float(d.get("eval_seconds", 0.0)),
                        "gpu": ((cfg.get("env") or {}).get("gpu") or {}).get("name")})
    return out


def estimate_budget(study, cu_per_hour: float | None = None, phase: str = "F1"):
    """Proyecta horas (y unidades de cómputo si das cu_per_hour) de lo que falta de F1 y de F3,
    a partir del tiempo MEDIDO de las corridas ya terminadas (o de F0.7 si F1 no empezó)."""
    import pandas as pd
    runs = study.paths.runs
    full = _done_runs(runs, f"{phase}/*/seed_*")
    trials = _done_runs(runs, f"{phase}/*/hpo/trial_*")
    source = phase
    if not full:
        full = _done_runs(runs, "F0.7/*/seed_*")
        source = "F0.7 (proxy: InfoNCE)"
    if not full:
        return {"nota": "Todavía no hay corridas medidas. Corre F0.7 o una celda de F1 y vuelve a ejecutar esta."}
    med = float(np.median([r["secs"] for r in full]))
    by_arm_full = {a: float(np.median([r["secs"] for r in full if r["arm"] == a])) for a in {r["arm"] for r in full}}
    by_arm_trial = {a: float(np.median([r["secs"] for r in trials if r["arm"] == a])) for a in {r["arm"] for r in trials}}
    med_trial = float(np.median([r["secs"] for r in trials])) if trials else med * study.hpo.budget_frac
    rows = []
    for arm in arm_names():
        ad = study.paths.d("runs", phase, arm)
        n_tr = len(_done_runs(ad, "hpo/trial_*"))
        n_sd = len(_done_runs(ad, "seed_*"))
        t_full = by_arm_full.get(arm, med)
        t_trial = by_arm_trial.get(arm, med_trial)
        rem = max(0, study.hpo.n_trials - n_tr) * t_trial + max(0, len(study.f1_seeds) - n_sd) * t_full
        rows.append({"brazo": arm, "trials_hechos": n_tr, "semillas_hechas": n_sd,
                     "min_por_corrida_completa": round(t_full / 60, 1), "horas_restantes_F1": round(rem / 3600, 2)})
    df = pd.DataFrame(rows)
    f1_h = float(df["horas_restantes_F1"].sum())
    f3_h = len(arm_names()) * len(study.f3_seeds) * med / 3600
    gpus = sorted({r["gpu"] for r in full if r["gpu"]})
    out = {"medido_en": source, "gpu_de_las_mediciones": gpus, "min_por_corrida_completa_mediana": round(med / 60, 1),
           "horas_restantes_F1": round(f1_h, 1), "horas_F3": round(f3_h, 1), "tabla": df}
    if cu_per_hour:
        out["unidades_restantes_F1"] = round(f1_h * cu_per_hour, 0)
        out["unidades_F3"] = round(f3_h * cu_per_hour, 0)
    return out


def tunability_report(study, phase: str = "F1", ns=(1, 2, 4, 8, 16, 32)):
    """Control de tunability (Dodge et al., 2019 [PENDING VERIFICATION]): desempeño de validación
    ESPERADO con n trials (de los trials al presupuesto reducido) y si el ranking de brazos cambia
    entre n = 8, 16 y 32."""
    import pandas as pd
    from scipy.stats import kendalltau
    from .hpo import expected_max_curve
    evp = {}
    for arm in arm_names():
        s = load_json(study.paths.d("runs", phase, arm, "hpo_summary.json"))
        if not s:
            continue
        vals = [t["val_best"] for t in s.get("trials", [])]
        c = expected_max_curve(vals, ns=[n for n in ns])
        evp[arm] = {n: c.get(n, np.nan) for n in ns}
    if len(evp) < 2:
        return {"nota": "se necesitan al menos 2 brazos con búsqueda de HP terminada"}
    df = pd.DataFrame(evp).T[list(ns)]
    ranks = df.rank(ascending=False, axis=0)
    n_max = max(n for n in ns if df[n].notna().all()) if any(df[n].notna().all() for n in ns) else None
    taus = {}
    if n_max is not None:
        for n in ns:
            if n < n_max and df[n].notna().all():
                taus[n] = float(kendalltau(ranks[n], ranks[n_max]).statistic)
    out_dir = makedirs(study.paths.d("results", phase, "tunability"))
    df.to_csv(os.path.join(out_dir, "evp_por_brazo.csv"))
    ranks.to_csv(os.path.join(out_dir, "ranking_por_presupuesto.csv"))
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    fig, ax = plt.subplots(figsize=(7, 4.5))
    for arm, row in df.iterrows():
        ax.plot(list(ns), row.values, marker="o", ms=3, label=arm)
    ax.set_xscale("log", base=2)
    ax.set_xlabel("nº de trials (presupuesto de tuning)")
    ax.set_ylabel("top-1 de validación esperado (mejor de n)")
    ax.legend(fontsize=6, ncol=2)
    fig.tight_layout()
    png = os.path.join(out_dir, "evp_curvas.png")
    fig.savefig(png, dpi=150)
    plt.close(fig)
    rep = {"n_referencia": n_max, "kendall_tau_vs_ref": taus, "png": png}
    save_json(rep, os.path.join(out_dir, "tunability.json"))
    return {"evp": df, "ranking": ranks, **rep}
